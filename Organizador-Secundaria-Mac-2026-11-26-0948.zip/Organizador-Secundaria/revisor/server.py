# -*- coding: utf-8 -*-
"""Revisor de Planeaciones — servidor local (solo 127.0.0.1)."""
import time, os, sys, re, json, uuid, base64, shutil, threading, subprocess, traceback, datetime, webbrowser
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import analyzer as A
from docxgen import generar, generar_obs, generar_aula
import rubrics as R

APP_DIR = os.path.dirname(HERE)
RESULTADOS = os.environ.get("REVISOR_DATOS") or os.path.join(APP_DIR, "RESULTADOS")   # dentro de «Organizador Secundaria» van fuera de la carpeta del programa (no se pierden al actualizar)
DATA = os.path.join(RESULTADOS, "_datos")
UPLOADS = os.path.join(DATA, "subidos")
PORT = int(os.environ.get("REVISOR_PORT", "8765"))
JOBS = {}
LOCK = threading.Lock()


def abrir_archivo(p):
    if sys.platform == "darwin":
        subprocess.Popen(["open", p])
    elif os.name == "nt":
        os.startfile(p)
    else:
        subprocess.Popen(["xdg-open", p])


def mostrar_en_carpeta(p):
    if sys.platform == "darwin":
        subprocess.Popen(["open", "-R", p])
    elif os.name == "nt":
        subprocess.Popen(["explorer", "/select,", os.path.normpath(p)])
    else:
        subprocess.Popen(["xdg-open", os.path.dirname(p)])


def a_la_papelera(f, raiz):
    """Mac: Papelera. Otros sistemas: carpeta «Resúmenes anteriores» dentro de la misma carpeta (no se borra nada)."""
    if sys.platform == "darwin":
        papelera = os.path.expanduser("~/.Trash")
    else:
        papelera = os.path.join(raiz, "Resumenes anteriores"); os.makedirs(papelera, exist_ok=True)
    dest = os.path.join(papelera, os.path.basename(f))
    if os.path.exists(dest):
        dest = os.path.join(papelera, time.strftime("%H%M%S ") + os.path.basename(f))
    shutil.move(f, dest)


def docentes_organizador():
    """Lista de docentes que manda «Organizador Secundaria» (REVISOR_DOCENTES = archivo JSON [{nombre, academia}])."""
    p = os.environ.get("REVISOR_DOCENTES")
    try:
        return [d for d in json.load(open(p, encoding="utf-8")) if d.get("nombre")] if p and os.path.exists(p) else []
    except Exception:
        return []

TRIM_DIR = re.compile(r"^\s*([123])\s*(?:°|º|er|ro|do|to|o|\.)?\s*t|^\s*trimestre\s*([123])", re.I)
SKIP_DIRS = re.compile(r"^(\.|INSTRUMENTOS|RESULTADOS|_)", re.I)


def trim_of(dirname):
    m = TRIM_DIR.match(dirname)
    return int(m.group(1) or m.group(2)) if m else None


def list_files(d):
    out = []
    for r, _, fs in os.walk(d):
        for f in sorted(fs):
            if f.startswith(".") or f.startswith("~$") or f.startswith("REVISION"):
                continue
            out.append(os.path.join(r, f))
    return out


def _item_docente(campo, dp, dn, trim):
    m = re.match(r"^(\d+)\s+\S+\s+(.*)$", dn)
    num, nombre = (m.group(1), m.group(2)) if m else ("", dn)
    subs = sorted(os.listdir(dp))
    tdirs = [os.path.join(dp, x) for x in subs if os.path.isdir(os.path.join(dp, x)) and trim_of(x) == trim]
    sueltos = [os.path.join(dp, x) for x in subs if os.path.isfile(os.path.join(dp, x)) and not x.startswith(".") and not x.startswith("REVISION")
               and A.trimestre_en_nombre(x) in (None, trim)]
    files, where = [], ""
    if tdirs:
        for td in tdirs:
            files += list_files(td)
        where = tdirs[0]
    elif sueltos and not any(os.path.isdir(os.path.join(dp, x)) and trim_of(x) for x in subs):
        files, where = sueltos, dp
    items = [{"path": f, "name": os.path.basename(f), "tipo": A.classify(os.path.basename(f))} for f in files]
    return {"campo": campo, "num": num, "docente": nombre, "dir": dp, "salida": where or dp,
            "estado": "listo" if any(i["tipo"] != "otro" for i in items) else ("solo_otros" if items else "sin_entrega"),
            "suelto": bool(not tdirs and files), "archivos": items}


def _es_carpeta_docente(dp):
    """Una carpeta de docente tiene archivos de planeación sueltos o subcarpetas de trimestre (1/2/3 TRIMESTRE)."""
    try:
        for x in os.listdir(dp):
            p = os.path.join(dp, x)
            if x.startswith(".") or x.startswith("~$"):
                continue
            if os.path.isdir(p) and trim_of(x):
                return True
            if os.path.isfile(p) and A.classify(x) != "otro" and not x.startswith("REVISION"):
                return True
    except OSError:
        pass
    return False


def _scan_carpetas(trim):
    """Acepta tres tipos de carpeta: la general (campo → docente → trimestre), la de un campo (docente → trimestre)
    o la de un solo docente (con sus archivos sueltos o sus carpetas de trimestre)."""
    cfg = A.load_config()
    root = cfg["root"]
    if not os.path.isdir(root):
        raise RuntimeError("La carpeta no existe: " + root)
    sub = [d for d in sorted(os.listdir(root)) if os.path.isdir(os.path.join(root, d)) and not SKIP_DIRS.match(d)]
    if _es_carpeta_docente(root):                                        # un solo docente
        return [_item_docente("", root, os.path.basename(root.rstrip(os.sep)), trim)]
    if sub and any(_es_carpeta_docente(os.path.join(root, d)) for d in sub):   # un campo formativo: sus docentes
        return [_item_docente(os.path.basename(root.rstrip(os.sep)), os.path.join(root, d), d, trim) for d in sub if not d.startswith(".")]
    out = []                                                             # carpeta general
    for campo in sub:
        cp = os.path.join(root, campo)
        for dn in sorted(os.listdir(cp)):
            dp = os.path.join(cp, dn)
            if os.path.isdir(dp) and not dn.startswith("."):
                out.append(_item_docente(campo, dp, dn, trim))
    return out


def _tokens_nombre(n):
    return [t for t in re.split(r"[^a-z]+", A.norm(n)) if len(t) > 1 and t not in ("de", "del", "la", "las", "los", "y")]


def mismo_docente(a, b):
    """¿Es la misma persona aunque el nombre esté escrito distinto en la lista de Personal y en su carpeta?
    Ej.: «KOH COBA» / «KOH COBAO», «MARCOS» / «MARCOA», apellidos en otro orden, o un segundo nombre de más
    («MARGARITA ROSA DE GUADALUPE SIERRA CEJIN» / «MARGARITA ROSA SIERRA CEJIN»). Con solo nombre + un apellido
    en común NO se junta (podrían ser hermanos o parientes)."""
    ta, tb = _tokens_nombre(a), _tokens_nombre(b)
    if not ta or not tb:
        return False
    if sorted(ta) == sorted(tb):
        return True
    corto, largo = (ta, tb) if len(ta) <= len(tb) else (tb, ta)
    if len(corto) >= 3 and set(corto) <= set(largo):
        return True
    if len(ta) == len(tb) and len(ta) >= 3:   # misma cantidad de palabras: una puede tener un error de dedo
        import difflib
        pares = sorted(zip(sorted(ta), sorted(tb)))
        dif = [(x, y) for x, y in zip(ta, tb) if x != y]
        if len(dif) == 1 and difflib.SequenceMatcher(None, dif[0][0], dif[0][1]).ratio() >= 0.8:
            return True
        dif2 = [(x, y) for x, y in pares if x != y]
        if len(dif2) == 1 and difflib.SequenceMatcher(None, dif2[0][0], dif2[0][1]).ratio() >= 0.8:
            return True
    return False


def scan(trim):
    """Docentes de la carpeta elegida + (si el Revisor se abrió desde «Organizador Secundaria») los de su lista de Personal
    que todavía no tienen carpeta: salen como «Sin entrega» para poder elegirlos y subirles archivos."""
    out = _scan_carpetas(trim)
    cfg = A.load_config()
    extra = docentes_organizador()
    if extra and len(out) != 1:
        conocidos = [A.norm(d["docente"]).strip() for d in out]
        for e in extra:
            k = A.norm(e["nombre"]).strip()
            if k and not any(mismo_docente(k, c) for c in conocidos):
                conocidos.append(k)
                out.append({"campo": (e.get("academia") or "").strip(), "num": "", "docente": e["nombre"].strip(), "dir": cfg["root"],
                            "salida": cfg["root"], "estado": "sin_entrega", "suelto": False, "archivos": [], "de_organizador": True})
    return out


def safe_under(path, bases):
    p = os.path.realpath(path)
    return any(p == os.path.realpath(b) or p.startswith(os.path.realpath(b) + os.sep) for b in bases)


def nombre_archivo(res):
    base = {"plano": "REVISION PLANO DIDACTICO", "guia_pa": "REVISION PROGRAMA ANALITICO", "obs": "OBSERVACION CLASE (FORMATO SUPERVISION)", "aula": "OBSERVACION CLASE"}[res["instrumento"]]
    et = re.sub(r"[^\w\s\-ñÑáéíóúÁÉÍÓÚ]", "", res.get("etiqueta", "")).strip()[:40]
    return "%s %sT - %s%s.docx" % (base, res.get("trimestre", ""), re.sub(r"[^\w\s\-ñÑáéíóúÁÉÍÓÚ]", "", res["docente"]).strip(), (" (%s)" % et) if et else "")


def _word_existente(r):
    """Si la revisión no trae su Word anotado pero el archivo YA existe en la carpeta del docente (se creó en otra corrida), se devuelve esa ruta
    para que «Revisiones guardadas» pueda mostrarlo."""
    try:
        salida = r.get("salida") or ""
        if salida and os.path.isdir(salida):
            p = os.path.join(salida, nombre_archivo(r))
            if os.path.isfile(p):
                return p
    except Exception:
        pass
    return ""


def todos_los_resultados():
    out = []
    if os.path.isdir(DATA):
        for f in os.listdir(DATA):
            if f.endswith(".json"):
                p = os.path.join(DATA, f)
                try:
                    out.append((os.path.getmtime(p), json.load(open(p, encoding="utf-8"))))
                except Exception:
                    pass
    return out


def crear_obs(cfg, doc, trim, salida, campo="", disciplina="", grado="", formato="aula"):
    """formato «aula» = Guía de Observación en el Aula (la de la escuela, 38 indicadores); «sup» = formato de la supervisión (4 dimensiones)."""
    if not safe_under(salida or RESULTADOS, [cfg["root"], RESULTADOS]):
        salida = RESULTADOS
    rid = "obs-" + uuid.uuid4().hex[:8]
    if formato != "sup":
        res = {"rid": rid, "instrumento": "aula", "docente": doc, "trimestre": int(trim), "campo": campo or "",
               "disciplina": disciplina, "grado": grado, "revisor": "", "fecha": "", "archivos": [], "salida": salida or RESULTADOS,
               "previo": contexto_previo(doc, trim), "aula": [["", ""] for _ in range(R.N_AULA)], "observaciones": "",
               "crops": {"aula": [""] * R.N_AULA}}
        os.makedirs(DATA, exist_ok=True)
        with open(os.path.join(DATA, rid + ".json"), "w", encoding="utf-8") as f:
            json.dump(res, f, ensure_ascii=False)
        return rid
    campo = re.sub(r"^campo\s+", "", campo or "", flags=re.I).capitalize()
    res = {"rid": rid, "instrumento": "obs", "docente": doc, "trimestre": int(trim), "campo": campo,
           "disciplina": disciplina, "grado": grado, "turno": "Matutino", "nivel": "Secundaria", "modalidad": "",
           "revisor": "", "fecha": "", "archivos": [], "salida": salida or RESULTADOS, "previo": contexto_previo(doc, trim),
           "generalidades": [["", ""] for _ in R.OBS_GENERALIDADES],
           "dims": [["" for _ in items] for _, items in R.OBS_DIMENSIONES], "observaciones": ""}
    os.makedirs(DATA, exist_ok=True)
    with open(os.path.join(DATA, rid + ".json"), "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False)
    return rid


def contexto_previo(docente, trim):
    """Resumen de la revisión de planeación más reciente del docente (para llevarlo a la observación de clase)."""
    nd = A.norm(docente).strip()
    mejores = {}
    for mt, r in sorted(todos_los_resultados(), key=lambda x: x[0]):
        if r.get("instrumento") in ("plano", "guia_pa") and A.norm(r["docente"]).strip() == nd and int(r.get("trimestre") or 0) == int(trim):
            mejores[r["instrumento"]] = r
    partes = []
    r = mejores.get("plano")
    if r:
        lv = [int(x[0]) for x in r["niveles"]]
        if any(lv):
            partes.append("Plano didáctico: %d reactivos en oportunidad (I-II) y %d en fortaleza (III-IV)." % (sum(1 for v in lv if v in (1, 2)), sum(1 for v in lv if v in (3, 4))))
            bajos = [it for (_, items) in R.FACTORES for it in items]
            falt = [bajos[i] for i, v in enumerate(lv) if v == 1][:5]
            if falt:
                partes.append("Nivel I (verificar en el aula): " + " · ".join(falt))
        if r.get("resumen") and not r["resumen"].startswith("ENTREGADO") and r["resumen"] != "Resumen simulado.":
            partes.append(r["resumen"])
        for o in r.get("otras", [])[:3]:
            if not o.startswith(("No hay clave", "Modo simulado")):
                partes.append(o)
    r = mejores.get("guia_pa")
    if r:
        g = [x[0] for x in r["guia"]]
        if any(g):
            partes.append("Programa analítico: %d indicadores NO y %d SÍ." % (g.count("NO"), g.count("SI")))
    return "\n".join(partes)


# ------------------------------------------------------------------ trabajos
def guardar_resultado(res, cfg, salida_forzada=None):
    """Genera el Word (+ PDF) de una revisión en su carpeta de salida y guarda el JSON. Devuelve (docx, pdf, pdf_oficial)."""
    rid = os.path.basename(res["rid"])
    salida = salida_forzada or res.get("salida") or RESULTADOS
    if not safe_under(salida, [cfg["root"], RESULTADOS]):
        salida = RESULTADOS
    out = os.path.join(salida, nombre_archivo(res))
    {"obs": generar_obs, "aula": generar_aula}.get(res["instrumento"], generar)(res, cfg, out)
    res["docx"] = out
    pdf = None
    try:  # el PDF es un extra: si LibreOffice no está, se entrega solo el Word
        tmp = A._convert(out, "pdf")
        if tmp and tmp.lower().endswith(".pdf"):
            pdf = os.path.splitext(out)[0] + ".pdf"
            shutil.move(tmp, pdf)
    except Exception:
        pdf = None
    res["pdf"] = pdf
    pdf_of = None
    if res["instrumento"] == "obs":   # además: el formato OFICIAL (PDF de la supervisión) ya lleno, listo para imprimir
        try:
            import obs_scan
            from docxgen import conteo_obs
            pdf_of = os.path.splitext(out)[0] + " (formato oficial).pdf"
            obs_scan.sellar_pdf(res, cfg, pdf_of, conteo_obs(res))
        except Exception:
            traceback.print_exc()
            pdf_of = None
    res["pdf_oficial"] = pdf_of
    res["borrador"] = False
    os.makedirs(DATA, exist_ok=True)
    with open(os.path.join(DATA, rid + ".json"), "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False)
    return out, pdf, pdf_of


def set_job(jid, **kw):
    with LOCK:
        JOBS[jid].update(kw)


def run_job(jid, tareas, cfg):
    """tareas: lista de dict(docente, trimestre, disciplina, grado, salida, archivos:[{path,tipo}])"""
    total = len(tareas)
    for i, t in enumerate(tareas):
        rid = "%s-%d" % (jid, i)
        entry = {"id": rid, "docente": t["docente"], "estado": "analizando", "msg": "", "resultados": [], "guardados": [], "avisos": []}
        with LOCK:
            JOBS[jid]["items"].append(entry)
        try:
            por_tipo = {}
            for f in t["archivos"]:
                if f["tipo"] in ("plano", "programa"):
                    por_tipo.setdefault(f["tipo"], []).append(f["path"])
            if not por_tipo and not t.get("con_obs"):
                raise RuntimeError("No hay archivos de planeación o programa analítico para revisar (todos marcados como «otro»).")
            grupos = []
            for tipo, paths in por_tipo.items():
                if t.get("por_archivo") and len(paths) > 1:
                    grupos += [(tipo, [p], os.path.splitext(os.path.basename(p))[0], k) for k, p in enumerate(paths)]
                else:
                    grupos.append((tipo, paths, "", 0))
            for tipo, paths, etiqueta, k in grupos:
                def prog(m, entry=entry, tipo=tipo, etiqueta=etiqueta):
                    entry["msg"] = ("[%s%s] " % ("Plano" if tipo == "plano" else "Programa analítico", (" · " + etiqueta[:30]) if etiqueta else "")) + m
                res = A.analizar(cfg, t["docente"], t["trimestre"], tipo, paths, t.get("disciplina", ""), t.get("grado", ""), prog)
                res["etiqueta"] = etiqueta
                res["salida"] = t["salida"]
                if not res.get("campo") and t.get("campo"):
                    res["campo"] = re.sub(r"^campo\s+", "", t["campo"], flags=re.I).capitalize()
                res["rid"] = "%s-%s%s" % (rid, tipo, ("-%d" % k) if etiqueta else "")
                os.makedirs(DATA, exist_ok=True)
                with open(os.path.join(DATA, res["rid"] + ".json"), "w", encoding="utf-8") as f:
                    json.dump(res, f, ensure_ascii=False)
                entry["resultados"].append({"rid": res["rid"], "tipo": tipo, "etiqueta": etiqueta})
                if t.get("auto_guardar") and (A.hay_ia(cfg) or os.environ.get("REVISOR_MOCK")):   # sin IA no se guardan revisiones vacías en las carpetas; «Analizar los planes de todos»: deja el Word y el PDF en la carpeta del docente
                    destino = os.path.join(t["salida"], nombre_archivo(res))
                    if os.path.exists(destino) and not t.get("sobrescribir"):
                        entry["avisos"].append("Ya existía «%s»: no se reemplazó (queda como borrador en «Revisiones guardadas»)." % os.path.basename(destino))
                    else:
                        guardar_resultado(res, cfg)
                        entry["guardados"].append(os.path.basename(destino))
            if t.get("con_obs"):
                orid = crear_obs(cfg, t["docente"], t["trimestre"], t["salida"], t.get("campo", ""), t.get("disciplina", ""), t.get("grado", ""))
                entry["resultados"].append({"rid": orid, "tipo": "obs", "etiqueta": ""})
            entry["estado"] = "listo"; entry["msg"] = ""
        except Exception as e:
            entry["estado"] = "error"; entry["msg"] = str(e)
            traceback.print_exc()
        set_job(jid, hechos=i + 1)
    set_job(jid, estado="terminado")


def start_job(tareas):
    cfg = A.load_config()
    jid = uuid.uuid4().hex[:8]
    JOBS[jid] = {"id": jid, "estado": "corriendo", "total": len(tareas), "hechos": 0, "items": []}
    threading.Thread(target=run_job, args=(jid, tareas, cfg), daemon=True).start()
    return jid


# ------------------------------------------------------------------ HTTP
class H(BaseHTTPRequestHandler):
    server_version = "Revisor/1.0"

    def log_message(self, *a):
        pass

    def _send(self, code, data, ctype="application/json; charset=utf-8"):
        body = data if isinstance(data, (bytes, bytearray)) else json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _ok_host(self):
        h = (self.headers.get("Host") or "").split(":")[0]
        return h in ("127.0.0.1", "localhost")

    def do_GET(self):
        if not self._ok_host():
            return self._send(403, {"error": "host"})
        u = urlparse(self.path); q = parse_qs(u.query)
        try:
            if u.path in ("/", "/index.html"):
                return self._send(200, open(os.path.join(HERE, "static", "index.html"), "rb").read(), "text/html; charset=utf-8")
            if u.path == "/api/config":
                cfg = A.load_config()
                return self._send(200, dict(A.public_config(cfg), mock=bool(os.environ.get("REVISOR_MOCK")), root_default=A.DEFAULTS["root"]))
            if u.path == "/api/meta":
                return self._send(200, {"factores": R.FACTORES, "guia": R.GUIA_PA, "obs_gen": R.OBS_GENERALIDADES, "obs_dim": R.OBS_DIMENSIONES,
                                        "obs_niv": R.OBS_NIVELES, "aula": R.GUIA_AULA})
            if u.path == "/api/scan":
                return self._send(200, {"docentes": scan(int(q.get("trim", ["1"])[0]))})
            if u.path.startswith("/api/job/"):
                jid = u.path.rsplit("/", 1)[1]
                with LOCK:
                    j = JOBS.get(jid)
                    return self._send(200, json.loads(json.dumps(j))) if j else self._send(404, {"error": "no existe"})
            if u.path.startswith("/api/result/"):
                rid = os.path.basename(u.path)
                return self._send(200, json.load(open(os.path.join(DATA, rid + ".json"), encoding="utf-8")))
            if u.path == "/api/excels":   # resúmenes en Excel ya generados (para abrirlos sin volver a generarlos)
                import glob
                cfg = A.load_config()
                fs = sorted(glob.glob(os.path.join(cfg["root"], "RESUMEN REVISION PLANEACIONES*.xlsx")), key=os.path.getmtime, reverse=True)
                return self._send(200, {"excels": [{"path": f, "name": os.path.basename(f),
                                                    "fecha": time.strftime("%d/%m/%Y %H:%M", time.localtime(os.path.getmtime(f)))} for f in fs]})
            if u.path == "/api/saved":
                out = []
                if os.path.isdir(DATA):
                    for f in sorted(os.listdir(DATA), key=lambda x: os.path.getmtime(os.path.join(DATA, x)), reverse=True):
                        if f.endswith(".json"):
                            try:
                                r = json.load(open(os.path.join(DATA, f), encoding="utf-8"))
                                out.append({"rid": r["rid"], "docente": r["docente"], "trimestre": r.get("trimestre"), "instrumento": r["instrumento"],
                                            "fecha": datetime.datetime.fromtimestamp(os.path.getmtime(os.path.join(DATA, f))).strftime("%d/%m/%Y %H:%M"),
                                            "docx": r.get("docx") or _word_existente(r), "borrador": bool(r.get("borrador"))})
                            except Exception:
                                pass
                return self._send(200, {"resultados": out[:60]})
            return self._send(404, {"error": "no encontrado"})
        except Exception as e:
            traceback.print_exc()
            return self._send(500, {"error": str(e)})

    def do_POST(self):
        if not self._ok_host() or self.headers.get("X-Revisor") != "1":
            return self._send(403, {"error": "solicitud no permitida"})
        n = int(self.headers.get("Content-Length") or 0)
        try:
            body = json.loads(self.rfile.read(n).decode("utf-8") or "{}")
        except Exception:
            return self._send(400, {"error": "JSON inválido"})
        u = urlparse(self.path)
        cfg = A.load_config()
        try:
            if u.path == "/api/config":
                return self._send(200, A.public_config(A.save_config(body)))
            if u.path == "/api/elegir_carpeta":   # ventana de macOS para elegir carpeta (no hace falta escribir la ruta)
                ini = cfg["root"] if os.path.isdir(cfg["root"]) else os.path.expanduser("~")
                if os.name == "nt":
                    ps = ('Add-Type -AssemblyName System.Windows.Forms; $d = New-Object System.Windows.Forms.FolderBrowserDialog; '
                          '$d.Description = "Elige la carpeta con los archivos del docente (o de todos los docentes)"; $d.SelectedPath = "%s"; '
                          'if ($d.ShowDialog() -eq "OK") { Write-Output $d.SelectedPath }' % ini.replace('"', ""))
                    r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True, timeout=600)
                    carpeta = r.stdout.strip()
                    if not carpeta:
                        return self._send(200, {"carpeta": ""})
                    if not os.path.isdir(carpeta):
                        raise RuntimeError("La carpeta elegida no existe.")
                    A.save_config({"root": carpeta})
                    return self._send(200, {"carpeta": carpeta})
                if sys.platform != "darwin":
                    raise RuntimeError("En este sistema escribe la ruta en ⚙ Configuración.")
                script = ('tell current application\nactivate\nset f to choose folder with prompt "Elige la carpeta con los archivos del docente (o de todos los docentes)" '
                          'default location (POSIX file "%s")\nPOSIX path of f\nend tell' % ini.replace('"', ""))
                r = subprocess.run(["osascript", "-e", script], capture_output=True, text=True, timeout=600)
                if r.returncode != 0:
                    if "-128" in r.stderr:      # el usuario canceló
                        return self._send(200, {"carpeta": ""})
                    raise RuntimeError("No se pudo abrir la ventana de carpetas: " + r.stderr.strip()[:200])
                carpeta = r.stdout.strip().rstrip("/") or ""
                if not os.path.isdir(carpeta):
                    raise RuntimeError("Carpeta no válida.")
                A.save_config({"root": carpeta})
                return self._send(200, {"carpeta": carpeta})
            if u.path == "/api/analyze_folder":
                tareas = []
                for d in body.get("docentes", []):
                    if not safe_under(d["salida"], [cfg["root"]]):
                        raise RuntimeError("Ruta fuera de la carpeta raíz.")
                    arch = [f for f in d["archivos"] if safe_under(f["path"], [cfg["root"]])]
                    tareas.append({"docente": d["docente"], "trimestre": body["trimestre"], "salida": d["salida"], "archivos": arch,
                                   "disciplina": d.get("disciplina", ""), "grado": d.get("grado", ""), "campo": d.get("campo", ""),
                                   "por_archivo": bool(body.get("por_archivo")), "con_obs": bool(body.get("con_obs")),
                                   "auto_guardar": bool(body.get("auto_guardar")), "sobrescribir": bool(body.get("sobrescribir"))})
                if not tareas:
                    raise RuntimeError("No seleccionaste docentes.")
                return self._send(200, {"job": start_job(tareas)})
            if u.path == "/api/analyze_upload":
                if not (body.get("docente") or "").strip():
                    raise RuntimeError("Escribe el nombre del docente.")
                if not body.get("files"):
                    raise RuntimeError("Sube al menos un archivo.")
                sub = os.path.join(UPLOADS, uuid.uuid4().hex[:8]); os.makedirs(sub)
                arch = []
                for f in body["files"]:
                    nm = os.path.basename(f["name"])
                    p = os.path.join(sub, nm)
                    with open(p, "wb") as fh:
                        fh.write(base64.b64decode(f["b64"]))
                    tipo = f.get("tipo") or A.classify(nm)
                    arch.append({"path": p, "name": nm, "tipo": "plano" if tipo == "otro" else tipo})
                t = {"docente": body["docente"].strip(), "trimestre": body.get("trimestre", 1), "salida": RESULTADOS, "archivos": arch,
                     "disciplina": body.get("disciplina", ""), "grado": body.get("grado", ""),
                     "por_archivo": bool(body.get("por_archivo")), "con_obs": bool(body.get("con_obs"))}
                return self._send(200, {"job": start_job([t])})
            if u.path == "/api/obs_new":
                doc = (body.get("docente") or "").strip()
                if not doc:
                    raise RuntimeError("Escribe el nombre del docente.")
                rid = crear_obs(cfg, doc, int(body.get("trimestre") or 1), body.get("salida") or RESULTADOS, body.get("campo", ""),
                                body.get("disciplina", ""), body.get("grado", ""), body.get("formato", "aula"))
                return self._send(200, {"rid": rid})
            if u.path == "/api/obs_leer":
                try:
                    import obs_scan
                except Exception as e:
                    raise RuntimeError("Falta un componente para leer imágenes (opencv/PyMuPDF). Cierra y vuelve a abrir con «Iniciar Revisor.command» para que se instale. (%s)" % e)
                arch = [(os.path.basename(f["name"]), base64.b64decode(f["b64"])) for f in body.get("files", [])]
                if not arch:
                    raise RuntimeError("Sube el PDF o las fotografías del formato.")
                if body.get("formato") == "aula":
                    import tabla_scan
                    return self._send(200, tabla_scan.leer(arch, ("SI", "NO", "PM", "NA"), R.N_AULA))
                return self._send(200, obs_scan.leer(arch))
            if u.path == "/api/excel":
                import resumen_excel
                out = resumen_excel.construir(cfg, {t: scan(t) for t in (1, 2, 3)}, todos_los_resultados(), cfg["root"])
                viejos = []   # los resúmenes antiguos por trimestre ya no hacen falta: pasan a la Papelera (no se borran para siempre)
                import glob
                for f in glob.glob(os.path.join(cfg["root"], "RESUMEN REVISION PLANEACIONES - * TRIMESTRE *.xlsx")):
                    if os.path.dirname(f) == cfg["root"] and f != out:
                        try:
                            a_la_papelera(f, cfg["root"])
                            viejos.append(os.path.basename(f))
                        except Exception:
                            traceback.print_exc()
                if body.get("abrir"):   # lo abre en Excel de una vez
                    try:
                        abrir_archivo(out)
                    except Exception:
                        pass
                return self._send(200, {"xlsx": out, "viejos": viejos})
            if u.path == "/api/draft":   # borrador automático: solo guarda los datos (marcas, textos), sin crear Word ni PDF
                res = body["resultado"]
                rid = os.path.basename(str(res.get("rid", "")))
                if not re.fullmatch(r"[\w\-]+", rid) or res.get("instrumento") not in ("plano", "guia_pa", "obs", "aula"):
                    raise RuntimeError("Borrador no válido.")
                res["rid"] = rid; res["borrador"] = True
                os.makedirs(DATA, exist_ok=True)
                tmp = os.path.join(DATA, rid + ".json.tmp")
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(res, f, ensure_ascii=False)
                os.replace(tmp, os.path.join(DATA, rid + ".json"))
                return self._send(200, {"ok": True})
            if u.path == "/api/save":
                res = body["resultado"]
                out, pdf, pdf_of = guardar_resultado(res, cfg)
                return self._send(200, {"docx": out, "pdf": pdf, "pdf_oficial": pdf_of})
            if u.path == "/api/reveal":
                p = body["path"]
                if not safe_under(p, [cfg["root"], RESULTADOS]) or not os.path.exists(p):
                    raise RuntimeError("Ruta no permitida.")
                mostrar_en_carpeta(p)
                return self._send(200, {"ok": True})
            if u.path == "/api/open":
                p = body["path"]
                if not safe_under(p, [cfg["root"], RESULTADOS]) or not os.path.exists(p):
                    raise RuntimeError("Ruta no permitida.")
                abrir_archivo(p)
                return self._send(200, {"ok": True})
            return self._send(404, {"error": "no encontrado"})
        except Exception as e:
            traceback.print_exc()
            return self._send(500, {"error": str(e)})


def main():
    os.makedirs(UPLOADS, exist_ok=True)
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), H)
    url = "http://127.0.0.1:%d/" % PORT
    print("Revisor de Planeaciones en", url, "(Ctrl+C para cerrar)")
    if not os.environ.get("REVISOR_NO_BROWSER"):
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
