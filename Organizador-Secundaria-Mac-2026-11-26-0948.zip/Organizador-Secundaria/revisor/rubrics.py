# -*- coding: utf-8 -*-
"""Instrumentos de revisión (Supervisión Secundarias Federales): reactivos y criterios."""

FACTORES = [
    ("Factor 1: Contextualización", [
        "Describe la problematización de la realidad que da sentido a la intervención didáctica.",
        "Enuncia los ejes articuladores que vinculan la realidad observada con los contenidos y PDA.",
    ]),
    ("Factor 2: Conocimiento del currículo", [
        "Se especifican los contenidos a trabajar y están descritos en el programa analítico.",
        "Se especifican los procesos de desarrollo de aprendizaje (PDA) que se abordarán en el periodo.",
        "Se especifican las finalidades del campo formativo a las que contribuirá.",
        "Se mencionan los rasgos del perfil de egreso a los que se contribuye.",
    ]),
    ("Factor 3: Estrategias didácticas", [
        "Enuncia alguna metodología sociocrítica propuesta por la NEM.",
        "Describe actividades congruentes con contenidos, PDA y metodología; favorece la interdisciplinariedad.",
        "Describe las actividades propuestas para alcanzar el perfil de egreso.",
        "Ajusta las estrategias de enseñanza y aprendizaje a la diversidad presente en el aula.",
        "Registra los recursos didácticos para el logro de contenidos y PDA.",
        "Describe diversos espacios para gestionar ambientes de aprendizaje (integridad de NNA).",
        "Especifica la temporalidad de cada actividad de las fases del proyecto o secuencia.",
    ]),
    ("Factor 4: Interacciones", [
        "Establece diversas formas de organización grupal (aprendizaje, participación y bienestar).",
        "Especifica los ajustes razonables para la inclusión de alumnos con alguna BAP.",
    ]),
    ("Factor 5: Evaluación formativa", [
        "Establece criterios de evaluación congruentes con los contenidos y PDA.",
        "Menciona técnicas e instrumentos de evaluación formativa pertinentes para el proceso.",
        "Menciona técnicas e instrumentos pertinentes para valorar el o los productos.",
        "Enuncia técnicas e instrumentos que toman en cuenta la diversidad presente en el aula.",
        "Incluye la retroalimentación a los alumnos al término de los temas o contenidos.",
    ]),
]
N_REACTIVOS = sum(len(i) for _, i in FACTORES)  # 20

GUIA_PA = [
    ("DATOS DE IDENTIFICACIÓN", [
        "Datos de la escuela (nombre de la escuela, CCT)",
        "Ciclo escolar",
        "Campo formativo",
        "Disciplina(s)",
        "Grado(s) y grupo(s)",
        "Docentes de cada disciplina",
    ]),
    ("PLANO 1: LECTURA DE LA REALIDAD", [
        "Factores del contexto interno (fortalezas y debilidades)",
        "Factores del contexto externo (oportunidades y amenazas)",
        "Problematización de la realidad (situaciones relevantes, prioridades, necesidades…)",
        "Describe las Barreras para el Aprendizaje y la Participación (BAP)",
    ]),
    ("PLANO 2: CONTEXTUALIZACIÓN", [
        "Problemática(s) y justificación",
        "Tipo de proyecto: áulico, escolar, comunitario",
        "Nombre del proyecto",
        "Propósito del proyecto",
        "El perfil de egreso",
        "Finalidades del campo formativo",
        "Especificidad del campo formativo",
        "Mapeo de contenidos de los programas sintéticos que se relacionan entre sí",
    ]),
    ("PLANO 3: FORMULACIÓN DEL PROGRAMA ANALÍTICO", [
        "Temporalidad (por cada periodo)",
        "Interdisciplinariedad",
        "Metodología y/o proyecto integrador",
        "Ejes articuladores por cada contenido",
        "PDA de cada disciplina del campo formativo",
        "Codiseño (contenidos y PDA no incluidos en los programas sintéticos) con justificación",
        "Orientaciones y estrategias didácticas generales",
        "EVALUACIÓN FORMATIVA: productos o entregables/evidencias",
        "EVALUACIÓN FORMATIVA: instrumentos de evaluación",
        "Observaciones, sugerencias, acuerdos y tareas",
    ]),
]
N_GUIA = sum(len(i) for _, i in GUIA_PA)  # 28

# Criterios de cada reactivo (resumen del Anexo 4.1) para la IA.
CRITERIOS_PLANO = """
NIVELES GENERALES: I = omite el aspecto o lo hace de forma incorrecta; II = cumple parcialmente; III = cumple de forma correcta y completa;
IV = cumple de manera extraordinaria (argumenta/justifica/enriquece). 0 = No aplica (solo si de verdad no es observable).

1.1 Problematización. I omite · II solo enuncia las situaciones · III describe situaciones que permiten identificar la problematización (que favorezcan reflexión y pensamiento crítico en la vida cotidiana) · IV describe Y argumenta.
1.2 Ejes articuladores. I omite · II los enuncia pero no son pertinentes (o los copia todos sin elegir) · III los enuncia con precisión y son pertinentes como vínculo realidad-contenidos-PDA · IV además argumenta con solidez su elección.
2.1 Contenidos. I omite · II los enuncia pero no corresponden al programa vigente · III todos especificados y están en el programa analítico · IV descritos todos y vinculados con claridad con los demás elementos de la planeación.
2.2 PDA. I omite · II los menciona · III los especifica, acordes con la disciplina · IV los describe con precisión y están en el programa analítico.
2.3 Finalidades del campo. I omite · II las menciona · III especifica el abordaje de las finalidades · IV especifica con claridad cómo la intervención contribuirá a ellas (copiar el texto sin explicar es II).
2.4 Perfil de egreso. I omite rasgos · II los menciona · III los argumenta · IV argumenta a profundidad (listar los 10 rasgos sin elegir es II).
3.1 Metodología. I omite · II menciona metodologías sin enfoque sociocrítico y activo · III enuncia las propuestas por la NEM (ABP/ABPC, STEAM, aprendizaje servicio, indagación, etc.) o equivalente y las justifica · IV describe y justifica.
3.2 Actividades. I omite · II algunas congruentes con contenidos/PDA y metodología · III describe actividades congruentes, favoreciendo la interdisciplinariedad · IV además las argumenta.
3.3 Actividades y perfil de egreso. I omite · II menciona de forma imprecisa · III describe cómo promueven cualidades/saberes del perfil · IV con claridad y suficiencia.
3.4 Diversidad en las estrategias. I omite · II responden parcialmente a la diversidad · III ajusta las estrategias a la diversidad del aula · IV atiende de manera diferenciada.
3.5 Recursos. I omite · II registra parcialmente · III registra los recursos disponibles en el plantel · IV además complementa con recursos propios, del contexto o la comunidad.
3.6 Espacios. I omite · II menciona espacios · III describe diversos espacios garantizando la integridad de NNA · IV describe y justifica.
3.7 Temporalidad. I omite · II parcial · III especifica la temporalidad de cada actividad de las fases/secuencia · IV precisa.
4.1 Organización grupal. I omite · II menciona algunas formas · III establece diversas formas (binas, tríadas, equipos…) · IV establece y justifica.
4.2 Ajustes razonables / BAP. I omite · II parcial · III especifica ajustes razonables para alumnos con BAP/NEE · IV con precisión.
5.1 Criterios de evaluación. I omite · II parcialmente congruentes · III congruentes con contenidos y PDA · IV además los justifica.
5.2 Técnicas/instrumentos del proceso. I no considera · II solo algunos pertinentes · III pertinentes para el proceso · IV diversos, agregando autoevaluación y coevaluación.
5.3 Técnicas/instrumentos de productos. I no considera · II solo algunos pertinentes · III pertinentes para los productos · IV diversos, con autoevaluación y coevaluación.
5.4 Evaluación y diversidad. I no enuncia · II algunas acordes con las características de los estudiantes · III toman en cuenta la diversidad · IV además autoevaluación/coevaluación.
5.5 Retroalimentación. I no describe · II algunos momentos · III describe los momentos y cómo contribuye a la mejora · IV momentos, manera de hacerlo y su contribución.
"""

SYSTEM_PROMPT = """Eres un(a) asesor(a) técnico-pedagógico de Educación Secundaria (México, Nueva Escuela Mexicana, Plan de Estudios 2022).
Revisas documentos de planeación de docentes aplicando los instrumentos oficiales de la Supervisión de Secundarias Federales:
(a) «Instrumento para la revisión del Plano Didáctico» (20 reactivos, niveles I-IV) y
(b) «Guía para el análisis de Programa Analítico» (28 indicadores SÍ/NO/N/A).
Reglas:
- Tu respuesta es un JSON válido. Dentro de los textos NUNCA uses comillas dobles ("): para citar usa comillas angulares «así» y no incluyas saltos de línea dentro de un texto.
- Basa cada valoración SOLO en lo que aparece en el texto entregado. Si algo no está, es nivel I (o NO). No inventes.
- Cada observación debe ser concreta (1-2 oraciones), citar evidencia breve del documento y, cuando sea útil, decir qué falta.
- Distingue copiar/transcribir texto del programa (nivel II) de describir/argumentar (nivel III-IV).
- Si hay varios archivos del mismo docente, da UNA valoración consolidada y menciona diferencias entre grupos/archivos en la observación.
- Sé justo(a) y profesional: reconoce fortalezas reales; no seas ni complaciente ni punitivo(a).
- Si el texto parece recortado o ilegible, dilo y marca la valoración como provisional en la observación.
- Responde ÚNICAMENTE con un objeto JSON válido (sin markdown, sin texto adicional)."""


# ---------------------------------------------------------------------------
# Formato 3: «Observación de la intervención didáctica» (Supervisión Secundarias Federales)
OBS_GENERALIDADES = [
    "Llegó puntual al salón de clase.",
    "Inicia puntualmente la sesión.",
    "Registró la asistencia de los alumnos a su clase.",
    "Lleva consigo el plan didáctico.",
    "Revisa la tarea asignada para la casa.",
    "Escribe en la pizarra o menciona a los alumnos el contenido y/o PDA(s) y/o objetivo de la clase a desarrollar.",
    "Recupera los saberes previos y los articula con los contenidos y/o PDA(S).",
]
OBS_NIVELES = [("RA", "Requiere apoyo", "No se relaciona con el descriptor o está ausente."),
               ("EP", "En proceso", "Se relaciona parcialmente con el descriptor, pero requiere mejorar."),
               ("L", "Logrado", "Se relaciona completamente con el descriptor."),
               ("D", "Destacado", "Se relaciona completamente con el descriptor y presenta propuestas o ideas innovadoras.")]
OBS_DIMENSIONES = [
    ("Dimensión 1: Implementación del currículo", [
        "Demuestra dominio de los principios de la Nueva Escuela Mexicana.",
        "Demuestra dominio de los contenidos y procesos de desarrollo de aprendizaje (PDA) de su disciplina con el uso de estrategias didácticas.",
        "Aclara las dudas que se presentan sobre la metodología utilizada en el desarrollo del proyecto.",
        "Adecúa los contenidos a las condiciones del contexto en las que se realizan los procesos de enseñanza y aprendizaje.",
        "Demuestra conocimiento sobre las características y necesidades de los estudiantes al abordar los contenidos.",
        "Promueve el vínculo comunitario a través de actividades donde los estudiantes demuestran lo aprendido.",
    ]),
    ("Dimensión 2: Ambiente para el aprendizaje", [
        "Establece acuerdos de convivencia en el aula que fomentan un clima de respeto, confianza y seguridad.",
        "Presenta actividades que propician ambientes de diálogo y confianza para la expresión de sentimientos, emociones o dudas.",
        "Evita cualquier forma de discriminación (género, cultura, lengua o alguna otra condición).",
        "Desarrolla sus actividades en espacios libres de las Barreras para el Aprendizaje y la Participación (BAP).",
        "Respeta el ritmo de aprendizaje de los estudiantes.",
        "Resuelve los conflictos mediante el diálogo y la mediación.",
        "Optimiza el tiempo de la clase para favorecer el logro de los PDA de los alumnos y concluye la clase en tiempo y forma.",
        "Recorre todos los espacios del salón de clases para supervisar que todos los alumnos se encuentren trabajando y así poder resolver las dudas que se vayan generando.",
    ]),
    ("Dimensión 3: Estrategias y recursos didácticos", [
        "Desarrolla la metodología (ABPC, STEAM, ABP, AS u otra) que aborda la situación problema.",
        "Desarrolla actividades en las que se distinguen las fases y/o momentos de la metodología seleccionada para el desarrollo del proyecto.",
        "Rescata los saberes previos indispensables para abordar los contenidos y PDA vinculados con la situación problema.",
        "Desarrolla actividades que permiten a los estudiantes organizarse en pequeñas comunidades de aprendizaje.",
        "Fomenta el uso de herramientas que permiten sistematizar el aprendizaje significativo de los estudiantes.",
        "Realiza actividades que consideran los estilos de aprendizaje de los estudiantes (visual, auditivo, kinestésico).",
        "Utiliza materiales y/o recursos didácticos durante el desarrollo del proyecto.",
        "Utiliza estrategias durante la intervención didáctica que favorecen el desarrollo del pensamiento crítico de los estudiantes.",
        "Emplea estrategias entre pares que permiten poner en práctica la metacognición.",
    ]),
    ("Dimensión 4: Evaluación", [
        "Utiliza criterios de evaluación acordes al proceso de desarrollo del proyecto.",
        "Retroalimenta de manera constante el proceso de desarrollo del proyecto.",
        "Emplea estrategias que propician la retroalimentación entre pares.",
        "Realiza actividades que propician la autoevaluación de los estudiantes durante el desarrollo del proyecto.",
        "Utiliza instrumentos o herramientas que permiten valorar el avance de los aprendizajes de los estudiantes.",
        "Utiliza estrategias didácticas que permiten interpretar el sentido del error para acordar una intervención pedagógica que conduzca al logro del aprendizaje.",
    ]),
]
N_OBS = sum(len(i) for _, i in OBS_DIMENSIONES)  # 29


# ---------------------------------------------------------------------------------------------------------------
# Guía de Observación en el Aula para Evaluar al Docente (formato de la escuela; 38 indicadores, SI / NO / Puede mejorar / NA)
GUIA_AULA = [
    ("GENERALIDADES", [
        "Llegó puntual al salón de clase.",
        "Inicia puntualmente la sesión.",
        "Registró la asistencia de los alumnos a su clase.",
        "Lleva consigo el plan didáctico.",
        "Revisa la tarea asignada para la casa, en caso de que haya.",
        "Escribe en la pizarra o menciona a los alumnos el contenido y/o PDA (s) y/o objetivo, propósito de la clase a desarrollar.",
    ]),
    ("ESTRATEGIAS DIDÁCTICAS", [
        "Recupera los saberes previos o recuerda lo estudiado en la clase anterior y los articula con los contenidos curriculares.",
        "Aborda los Contenidos, PDAS y Ejes articuladores relacionándolos con aspectos significativos para sus estudiantes (Actividades contextualizadas).",
        "La estrategias y actividades empleadas permiten al alumno construir su conocimiento siendo él el protagonista del mismo.",
        "Utiliza estrategias en diferentes momentos de la intervención didáctica que favorecen la recuperación, integración, y consolidación de los contenidos y PDA(S).",
        "Utiliza estrategias diversas para atender los estilos, ritmos y procesos de aprendizaje de todo el alumnado.",
        "Existe una secuencia ordenada y lógica en las actividades desarrolladas.",
        "Emplea actividades lúdicas y/o dinámicas para promover la participación e interés del estudiante en el proceso de enseñanza-aprendizaje.",
        "Promueve el trabajo colaborativo para favorecer la inclusión y participación de todos sus estudiantes.",
        "Se desarrollaron las actividades conforme a lo planeado por escrito.",
        "Las estrategias y actividades realizadas promueven los ejes articuladores propios del Contenido y PDA estudiado.",
    ]),
    ("RECURSOS DIDÁCTICOS", [
        "Los recursos didácticos empleados por el docente logran captar el interés de sus estudiantes en la actividad de la clase.",
        "Utiliza materiales didácticos, recursos físicos y/o digitales de acuerdo con las características del contexto.",
        "Emplea recursos didácticos que favorecen la elaboración de los productos o evidencias para la evaluación.",
    ]),
    ("ORGANIZACIÓN Y DESARROLLO DE LA CLASE", [
        "Organiza al grupo para iniciar y desarrollar la sesión.",
        "El desarrollo de la clase tuvo un inicio, desarrollo y cierre",
        "Optimiza el tiempo de la clase para favorecer el logro del propósito de la sesión. Concluye la clase en tiempo y forma.",
        "Explica de forma clara, sencilla, adecuada y de fácil comprensión para los alumnos, los procedimientos, consignas, instrucciones y/o reglas.",
        "Fomenta el diálogo como medio para la generación de vínculos pedagógicos.",
        "Escucha y atiende con respeto los comentarios de sus alumnos.",
        "Favorece la participación de todos los estudiantes, a nivel individual y colectivo para el aprendizaje de los alumnos.",
        "Existe un trato amable y respetuoso al dirigirse a sus alumnos.",
        "Los estudiantes se mantienen activos (respondiendo, cuestionando, manipulando, interactuando, creando…) durante la clase.",
        "Mantiene un control de disciplina mediante la aplicación de los acuerdos de convivencia (la vía del trabajo, no la coercitiva)",
        "Recorre todos los espacios del salón de clases para supervisar que todos los alumnos se encuentren trabajando y así poder resolver las dudas que se vayan generando.",
        "Promueve la creación de un ambiente de Convivencia saludable durante la intervención didáctica, basada en el respeto y la inclusión entre todos los actores educativos.",
    ]),
    ("EVALUACIÓN", [
        "Realiza la evaluación formativa durante la clase.",
        "Emplea técnica y/o instrumento que son acordes para la evaluación de las actividades y los PDA(S).",
        "Utiliza algún instrumento, lista de asistencia o documento visible para registrar el desempeño de los alumnos.",
        "Los mecanismos e instrumentos de evaluación empleados permiten identificar con claridad los aprendizajes alcanzados y los que requieren fortalecer.",
        "Se obtienen evidencias del aprendizaje alcanzado de la intención didáctica planteados para la sesión.",
        "Propicia la socialización de las producciones de los alumnos.",
        "Utiliza los resultados de la evaluación para retroalimentar a sus estudiantes de forma escrita y/o verbal.",
    ]),
]
N_AULA = sum(len(i) for _, i in GUIA_AULA)
assert N_AULA == 38
