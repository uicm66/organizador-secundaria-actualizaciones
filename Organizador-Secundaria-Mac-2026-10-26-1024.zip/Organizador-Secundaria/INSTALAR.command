#!/bin/bash
# INSTALAR / ACTUALIZAR — Organizador Secundaria (Mac, Intel y Apple Silicon)
# Doble clic (la primera vez: clic derecho > Abrir). Sirve para INSTALAR y también para ACTUALIZAR:
# copia el programa a un lugar fijo, y crea en el Escritorio el acceso directo "Organizador Secundaria".
# Tus datos (navegador) y tu licencia (carpeta de usuario) NO se tocan. Después puedes borrar esta carpeta y el .zip.
cd "$(dirname "$0")" || exit 1
BASE="$HOME/Library/Application Support/OrganizadorSecundaria"
DEST="$BASE/Programa"
ESCRITORIO="${FCP_ESCRITORIO:-$HOME/Desktop}"
PUERTO="${FCP_PUERTO:-5544}"
aviso() { [ -n "$FCP_NO_ABRIR" ] && return 0; osascript -e "display dialog \"$1\" buttons {\"OK\"} default button \"OK\" with title \"Organizador Secundaria\"" >/dev/null 2>&1; }

echo "=== Organizador Secundaria — instalar / actualizar ==="
# 1) Node.js
NODE=""
for c in /usr/local/bin/node /opt/homebrew/bin/node; do [ -x "$c" ] && NODE="$c" && break; done
[ -z "$NODE" ] && NODE="$(/bin/zsh -lc 'command -v node' 2>/dev/null)"
if [ -z "$NODE" ]; then
  aviso "Falta instalar Node.js (un programa gratuito de apoyo).\n\nAbre el instalador node-…pkg que te enviaron, instálalo y vuelve a abrir INSTALAR."
  echo "Falta Node.js: instálalo (node-...pkg) y vuelve a abrir este archivo."; read -p "Enter para cerrar..."; exit 1
fi

# 2) Detener el programa si estaba abierto (actualización)
for pid in $(lsof -ti tcp:$PUERTO -sTCP:LISTEN 2>/dev/null); do
  if ps -o command= -p "$pid" 2>/dev/null | grep -q "server.js"; then kill "$pid" 2>/dev/null; fi
done
sleep 1

# 3) Copiar el programa a su lugar fijo
mkdir -p "$BASE"
# Los horarios que subió la escuela (horarios/) NO se pierden al reinstalar: se apartan y se devuelven.
rm -rf "$BASE/.horarios-apartados"
[ -d "$DEST/horarios" ] && mv "$DEST/horarios" "$BASE/.horarios-apartados"
rm -rf "$DEST"
mkdir -p "$DEST"
cp -R ./ "$DEST/" || { aviso "No se pudo copiar el programa."; exit 1; }
if [ -d "$BASE/.horarios-apartados" ]; then mkdir -p "$DEST/horarios"; cp -R "$BASE/.horarios-apartados/." "$DEST/horarios/" && rm -rf "$BASE/.horarios-apartados"; fi
rm -f "$DEST/INSTALAR.bat" 2>/dev/null
xattr -dr com.apple.quarantine "$DEST" 2>/dev/null
chmod +x "$DEST"/*.command 2>/dev/null

# 4) (el icono se genera al final con el logo de la escuela, o el predeterminado)

# 5) Acceso directos en el Escritorio (sin ventana negra)
crear_app() {   # $1 = nombre, $2 = id, $3 = modo (normal|celulares)
  APP="$ESCRITORIO/$1.app"
  rm -rf "$APP"; mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
  cat > "$APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleName</key><string>$1</string><key>CFBundleDisplayName</key><string>$1</string>
<key>CFBundleIdentifier</key><string>mx.organizador.$2</string><key>CFBundleExecutable</key><string>Abrir</string>
<key>CFBundleIconFile</key><string>icono</string><key>CFBundlePackageType</key><string>APPL</string><key>LSUIElement</key><true/>
</dict></plist>
PLIST
  cat > "$APP/Contents/MacOS/Abrir" <<'LANZADOR'
#!/bin/bash
BASE="$HOME/Library/Application Support/OrganizadorSecundaria"; DEST="$BASE/Programa"; PUERTO="${FCP_PUERTO:-5544}"
MODO="__MODO__"
NODE=""; for c in /usr/local/bin/node /opt/homebrew/bin/node; do [ -x "$c" ] && NODE="$c" && break; done
[ -z "$NODE" ] && NODE="$(/bin/zsh -lc 'command -v node' 2>/dev/null)"
[ -z "$NODE" ] && { osascript -e 'display dialog "Falta instalar Node.js. Abre el instalador node-…pkg que te enviaron." buttons {"OK"}' >/dev/null 2>&1; exit 1; }
[ -d "$DEST" ] || { osascript -e 'display dialog "El programa no está instalado. Abre INSTALAR.command." buttons {"OK"}' >/dev/null 2>&1; exit 1; }
corriendo() { curl -s -m 1 -o /dev/null "http://127.0.0.1:$PUERTO/api/licencia/estado"; }
if [ "$MODO" = "celulares" ]; then
  for pid in $(lsof -ti tcp:$PUERTO -sTCP:LISTEN 2>/dev/null); do ps -o command= -p "$pid" | grep -q "server.js" && kill "$pid"; done; sleep 1
  ( cd "$DEST" && FCP_RED=1 FCP_PUERTO=$PUERTO nohup "$NODE" server.js >> "$BASE/servidor.log" 2>&1 & )
else
  if ! corriendo; then ( cd "$DEST" && FCP_PUERTO=$PUERTO nohup "$NODE" server.js >> "$BASE/servidor.log" 2>&1 & ); fi
fi
for i in $(seq 1 60); do corriendo && break; sleep 0.25; done
if [ "$MODO" = "celulares" ]; then
  IP="$(ipconfig getifaddr en0 2>/dev/null || ipconfig getifaddr en1 2>/dev/null)"
  LINK="http://$IP:$PUERTO/prefectos/index.html"
  printf "%s" "$LINK" | pbcopy
  [ -z "$FCP_NO_ABRIR" ] && osascript -e "display dialog \"Enlace para las prefectas (ya copiado, solo pégalo en WhatsApp):\n\n$LINK\n\nLas prefectas deben estar en el MISMO wifi y esta computadora encendida.\" buttons {\"OK\"} with title \"Reportes de prefectas\"" >/dev/null 2>&1
fi
[ -z "$FCP_NO_ABRIR" ] && open "http://localhost:$PUERTO"
LANZADOR
  sed -i '' "s/__MODO__/$3/" "$APP/Contents/MacOS/Abrir"
  chmod +x "$APP/Contents/MacOS/Abrir"
  xattr -cr "$APP" 2>/dev/null
}
crear_app "Organizador Secundaria" principal normal
crear_app "Organizador Secundaria (celulares)" celulares celulares

# icono de los accesos = logo de la escuela (si ya lo subió) o el predeterminado
FCP_ESCRITORIO="$ESCRITORIO" "$NODE" "$DEST/server.js" --actualizar-iconos >/dev/null 2>&1

aviso "Listo. Se instaló el programa y se creó en tu Escritorio el icono «Organizador Secundaria». Úsalo siempre que quieras abrirlo.\n\nYa puedes borrar esta carpeta y el .zip."
echo ""; echo "Instalado en: $DEST"; echo "Acceso directo: $ESCRITORIO/Organizador Secundaria.app"
[ -z "$FCP_NO_ABRIR" ] && open "$ESCRITORIO/Organizador Secundaria.app"
read -p "Presiona Enter para cerrar esta ventana..." </dev/tty 2>/dev/null || true
