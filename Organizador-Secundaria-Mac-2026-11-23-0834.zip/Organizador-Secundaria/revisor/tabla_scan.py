# -*- coding: utf-8 -*-
"""Lectura de tablas de palomeo (SÍ / NO / Puede mejorar / NA) llenadas a mano y escaneadas o fotografiadas.

No necesita plantilla: encuentra por sí sola las líneas de la tabla, separa las filas de indicadores de los
renglones de título, y mide la tinta que hay dentro de cada casilla. Sirve para la «Guía de Observación en
el Aula» y para la «Guía del Programa Analítico» (cambia el número de columnas y de indicadores).
Siempre debe revisarse en pantalla: las casillas dudosas se marcan.
"""
import base64
import numpy as np
import cv2

import obs_scan as O   # decodificar() (PDF / JPG / PNG / HEIC → imágenes)

UMBRAL_REL = 0.012       # fracción mínima de tinta en la casilla para considerarla marcada
UMBRAL_ABS = 60          # …y píxeles mínimos (a ~200 dpi)


def _gris_normal(img):
    g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    fondo = cv2.medianBlur(cv2.resize(g, None, fx=0.25, fy=0.25, interpolation=cv2.INTER_AREA), 31)
    fondo = cv2.resize(fondo, (g.shape[1], g.shape[0]), interpolation=cv2.INTER_LINEAR)
    n = np.clip(g.astype(np.float32) / np.maximum(fondo, 1) * 235, 0, 255).astype(np.uint8)
    return n


def _enderezar(img):
    """Gira la hoja si está torcida (ángulo medido con las líneas largas de la tabla)."""
    g = _gris_normal(img)
    bn = cv2.threshold(g, 150, 255, cv2.THRESH_BINARY_INV)[1]
    w = bn.shape[1]
    lin = cv2.morphologyEx(bn, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (max(w // 6, 50), 1)))
    ls = cv2.HoughLinesP(lin, 1, np.pi / 720, 200, minLineLength=w // 5, maxLineGap=30)
    if ls is None:
        return img
    ang = []
    for x1, y1, x2, y2 in np.asarray(ls).reshape(-1, 4):
        a = np.degrees(np.arctan2(y2 - y1, x2 - x1))
        if abs(a) < 6:
            ang.append(a)
    if not ang:
        return img
    a = float(np.median(ang))
    if abs(a) < 0.15:
        return img
    h, w = img.shape[:2]
    M = cv2.getRotationMatrix2D((w / 2, h / 2), a, 1.0)
    return cv2.warpAffine(img, M, (w, h), flags=cv2.INTER_LINEAR, borderValue=(255, 255, 255))


def _picos(perfil, minimo, sep):
    """Posiciones donde el perfil supera `minimo`, fusionando las que están a menos de `sep`."""
    idx = np.where(perfil >= minimo)[0]
    grupos, cur = [], []
    for i in idx:
        if cur and i - cur[-1] > sep:
            grupos.append(cur); cur = []
        cur.append(i)
    if cur:
        grupos.append(cur)
    out = []
    for g in grupos:
        w = perfil[g]
        out.append(float(np.average(g, weights=w)))
    return out


def _analizar_hoja(img, ncols):
    """Devuelve dict con filas de indicadores de una hoja o None si no hay tabla.
    ncols = número de columnas de casillas (4: SI NO PM NA · 3: SI NO NA)."""
    img = _enderezar(img)
    g = _gris_normal(img)
    H, W = g.shape
    bn = cv2.threshold(g, 160, 255, cv2.THRESH_BINARY_INV)[1]
    hor = cv2.morphologyEx(bn, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (max(W // 12, 60), 1)))
    ver = cv2.morphologyEx(bn, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (1, 28)))
    # líneas verticales: posiciones x donde hay mucha línea
    pv = (ver > 0).sum(axis=0).astype(np.float32)
    if pv.max() < H * 0.12:
        return None
    xs = _picos(pv, max(pv.max() * 0.35, 80), 8)
    if len(xs) < ncols + 3:
        return None
    # La tabla: las últimas ncols+2 líneas son: [..., izq SI, SI|NO, …, der NA, der Observaciones]
    # Se buscan ncols+1 líneas consecutivas con separación pareja (columnas de casillas) seguidas de una más (Observaciones).
    mejor = None
    for i in range(len(xs) - ncols):
        seg = xs[i:i + ncols + 1]
        anchos = np.diff(seg)
        if anchos.min() < W * 0.025 or anchos.max() > W * 0.12:
            continue
        reg = anchos.max() / max(anchos.min(), 1)
        if reg > 1.8:
            continue
        sc = -reg
        if mejor is None or sc > mejor[0]:
            mejor = (sc, i)
    if mejor is None:
        return None
    i0 = mejor[1]
    cx = xs[i0:i0 + ncols + 1]                         # límites de las casillas
    x_izq_tabla = xs[0]
    x_obs_der = xs[i0 + ncols + 1] if len(xs) > i0 + ncols + 1 else min(W - 5, cx[-1] + W * 0.25)
    # líneas horizontales dentro de la zona de la tabla
    ph = (hor[:, int(x_izq_tabla):int(cx[-1])] > 0).sum(axis=1).astype(np.float32)
    anch = max(cx[-1] - x_izq_tabla, 1)
    ys = _picos(ph, anch * 0.5, 5)
    if len(ys) < 3:
        return None
    filas = []
    for a, b in zip(ys[:-1], ys[1:]):
        if b - a < 18:
            continue
        ya, yb = int(a), int(b)
        banda_cas = bn[ya + 5:yb - 5, int(cx[0]) + 6:int(cx[-1]) - 6]
        if banda_cas.size == 0:
            continue
        oscuro = float((banda_cas > 0).mean())
        # cobertura de las líneas verticales de las casillas dentro de la banda
        cov = []
        for x in cx:
            xa, xb = max(int(x) - 4, 0), int(x) + 5
            cov.append(float((ver[ya + 4:yb - 4, xa:xb] > 0).any(axis=1).mean()))
        filas.append({"y0": a, "y1": b, "oscuro": oscuro, "cov": float(np.mean(cov)), "cov_min": float(min(cov))})
    return {"img": img, "g": g, "bn": bn, "hor": hor, "ver": ver, "cx": cx, "xizq": x_izq_tabla, "xobs": x_obs_der,
            "ys": ys, "filas": filas, "H": H, "W": W}


def _es_indicador(f):
    return f["cov"] >= 0.55 and f["oscuro"] < 0.45 and (f["y1"] - f["y0"]) >= 22


def _png(img):
    ok, buf = cv2.imencode(".png", img)
    return base64.b64encode(buf.tobytes()).decode()


def _jpg(img, ancho=900):
    h, w = img.shape[:2]
    sc = ancho / float(w)
    ok, buf = cv2.imencode(".jpg", cv2.resize(img, None, fx=sc, fy=sc, interpolation=cv2.INTER_AREA), [cv2.IMWRITE_JPEG_QUALITY, 70])
    return base64.b64encode(buf.tobytes()).decode()


def _recorte_celda(hoja, f, x0, x1):
    """Recorte (PNG base64) de lo escrito a mano en la celda de observaciones, o ''."""
    ya, yb = int(f["y0"]) + 3, int(f["y1"]) - 3
    xa, xb = int(x0) + 4, int(x1) - 4
    if xb - xa < 20 or yb - ya < 10:
        return ""
    reg = hoja["bn"][ya:yb, xa:xb].copy()
    reg[(hoja["hor"][ya:yb, xa:xb] > 0)] = 0
    reg[(hoja["ver"][ya:yb, xa:xb] > 0)] = 0
    if int((reg > 0).sum()) < 400:
        return ""
    color = hoja["img"][ya:yb, xa:xb]
    claro = O._limpia(color) if hasattr(O, "_limpia") else color
    h, w = claro.shape[:2]
    if w > 520:
        claro = cv2.resize(claro, None, fx=520.0 / w, fy=520.0 / w, interpolation=cv2.INTER_AREA)
    return _png(claro)


def leer(archivos, cols, n_esperado):
    """archivos: [(nombre, bytes)]; cols: p. ej. ('SI','NO','PM','NA'); n_esperado: nº de indicadores.
    → {valores:[n], dudas:[idx], avisos, previews, obs_crops:[n], encabezado, marcas, hojas}"""
    avisos, hojas = [], []
    for nombre, datos in archivos:
        try:
            imgs = O.decodificar(nombre, datos)
        except Exception as e:
            avisos.append("No se pudo abrir «%s»: %s" % (nombre, e)); continue
        if not imgs:
            avisos.append("No se pudo abrir «%s»." % nombre)
        for k, im in enumerate(imgs):
            hojas.append((nombre if len(imgs) == 1 else "%s (pág. %d)" % (nombre, k + 1), im))
    if not hojas:
        raise RuntimeError("No se pudo abrir ninguna imagen o PDF.")
    # hojas con tabla
    tablas = []
    for nombre, im in hojas:
        try:
            r = _analizar_hoja(im, len(cols))
        except Exception:
            r = None
        if not r:
            avisos.append("«%s» no parece una hoja con la tabla de indicadores (se omitió; las hojas de texto son normales)." % nombre)
            continue
        ind = [f for f in r["filas"] if _es_indicador(f)]
        if len(ind) < 3:
            avisos.append("«%s»: no se reconocieron filas de indicadores (¿foto movida o recortada?)." % nombre)
            continue
        tablas.append((nombre, r, ind))
    if not tablas:
        raise RuntimeError("No se reconoció la tabla de indicadores. Usa un escaneo o una foto de la hoja completa, derecha y con buena luz.")
    # orden: el de subida; si una hoja trae encabezado (arriba hay texto) es la primera: se respeta el orden dado.
    n_leidos = sum(len(t[2]) for t in tablas)
    if n_leidos != n_esperado:
        avisos.append("Se encontraron %d filas de indicadores y el formato tiene %d: revisa TODAS las marcas con cuidado (puede faltar una hoja o estar repetida)." % (n_leidos, n_esperado))
    valores, dudas, crops, previews = [], [], [], []
    marcas = 0
    for nombre, r, ind in tablas:
        prev = r["img"].copy()
        for f in ind:
            ink = []
            for k in range(len(cols)):
                xa, xb = int(r["cx"][k]) + 5, int(r["cx"][k + 1]) - 4
                ya, yb = int(f["y0"]) + 5, int(f["y1"]) - 4
                reg = r["bn"][ya:yb, xa:xb].copy()
                reg[cv2.dilate(r["hor"][ya:yb, xa:xb], np.ones((5, 5), np.uint8)) > 0] = 0
                reg[cv2.dilate(r["ver"][ya:yb, xa:xb], np.ones((5, 5), np.uint8)) > 0] = 0
                ink.append(int((reg > 0).sum()))
                area = max((xb - xa) * (yb - ya), 1)
                ink[-1] = (ink[-1], area)
            tot = [a for a, _ in ink]
            area = ink[0][1]
            m = int(np.argmax(tot))
            idx = len(valores)
            umbral = max(UMBRAL_ABS, UMBRAL_REL * area)
            dud = False
            if tot[m] < umbral:
                valores.append("")
                if tot[m] > umbral * 0.5:
                    dud = True   # marca muy débil
            else:
                valores.append(cols[m]); marcas += 1
                otros = sorted(tot)[-2]
                if otros >= tot[m] * 0.55 and otros >= umbral * 0.8:
                    dud = True   # dos casillas con tinta parecida
            if dud:
                dudas.append(idx)
            crops.append(_recorte_celda(r, f, r["cx"][-1], r["xobs"]))
            col = (0, 0, 255) if dud else (0, 170, 0)
            if valores[idx]:
                k = cols.index(valores[idx])
                cv2.rectangle(prev, (int(r["cx"][k]) + 2, int(f["y0"]) + 2), (int(r["cx"][k + 1]) - 2, int(f["y1"]) - 2), col, 3)
            elif dud:
                cv2.rectangle(prev, (int(r["cx"][0]) + 2, int(f["y0"]) + 2), (int(r["cx"][-1]) - 2, int(f["y1"]) - 2), col, 2)
        previews.append({"hoja": nombre, "img": _jpg(prev)})
    # encabezado manuscrito: lo que hay arriba de la primera fila de la primera hoja con tabla
    enc = ""
    nombre, r, ind = tablas[0]
    top = int(max(r["ys"][0] - 5, 0))
    if top > 120:
        enc = _png(cv2.resize(r["img"][:top], None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA))
    return {"valores": valores, "dudas": dudas, "avisos": avisos, "previews": previews, "crops": crops,
            "encabezado": enc, "marcas": marcas, "hojas": [t[0] for t in tablas], "filas": n_leidos, "esperado": n_esperado}
