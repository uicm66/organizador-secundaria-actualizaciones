# -*- coding: utf-8 -*-
"""Resumen en Excel de la revisión de planeaciones del ciclo (1.º, 2.º y 3.er trimestre): control de entrega + hallazgos + observaciones de clase."""
import os
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
import analyzer as A
from docxgen import conteo_obs, conteo_aula

AZUL = PatternFill("solid", fgColor="1F3864")
THIN = Side(style="thin", color="B0B5BD")
BORDE = Border(top=THIN, bottom=THIN, left=THIN, right=THIN)
TRIM = {1: "PRIMER", 2: "SEGUNDO", 3: "TERCER"}


def disciplina_sugerida(campo, num):
    """Disciplina según la numeración de la lista de docentes 2026-27 (aproximada: confirmar)."""
    try:
        n = int(num)
    except Exception:
        return ""
    c = (campo or "").upper()
    if "LENGUAJES" in c:
        return "Español" if n <= 6 else "Inglés" if n <= 34 else "Artes"
    if "SABERES" in c:
        return "Saberes (por confirmar)" if n in (20, 21) else ("Matemáticas" if n <= 11 else "Ciencias")
    if "HUMANO" in c:
        return "Educación Física" if n <= 38 else "Tecnología"
    if "ETICA" in c:
        return "Ciencias Sociales"
    return ""


def _head(ws, row, titles, widths):
    ws.append(titles)
    for c in ws[row]:
        c.font = Font(bold=True, color="FFFFFF"); c.fill = AZUL
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w


def _ultimos(resultados, trim):
    """Última revisión guardada por (docente, instrumento) de este trimestre. resultados: [(mtime, dict)]."""
    out = {}
    for mt, r in sorted(resultados, key=lambda x: x[0]):
        if int(r.get("trimestre") or 0) != int(trim):
            continue
        out[(A.norm(r["docente"]).strip(), r["instrumento"])] = r
    return out


def _fila_hallazgo(r, ins):
    prob = "; ".join("%s: %s" % (e[0], e[2]) for e in r.get("identificacion", []) if e[1] != "ok") or "Sin observaciones"
    if ins == "plano":
        lv = [int(x[0]) for x in r["niveles"]]
        if all(v == 0 for v in lv):
            res = "Niveles sin asignar"
        else:
            res = "%d reactivos en oportunidad (I-II) / %d en fortaleza (III-IV)" % (sum(1 for v in lv if v in (1, 2)), sum(1 for v in lv if v in (3, 4)))
    else:
        g = [x[0] for x in r["guia"]]
        if not any(g):
            res = "Indicadores sin revisar"
        else:
            res = "%d indicadores NO / %d SÍ" % (g.count("NO"), g.count("SI")) + (" (%d sin marcar)" % g.count("") if g.count("") else "")
    obs = r.get("resumen") or ""
    if r.get("otras"):
        obs = (obs + " " if obs and not obs.startswith("ENTREGADO") else "") + " ".join(r["otras"][:4])
    return prob, res, obs.strip()


def construir(cfg, docentes_por_trim, resultados, destino_dir):
    """Un solo libro para el ciclo: el Control tiene un bloque de columnas por trimestre (1.º, 2.º y 3.º) y hay una hoja
    de hallazgos por cada trimestre que ya tiene revisiones. docentes_por_trim: {1: scan(1), 2: scan(2), 3: scan(3)}."""
    trims = (1, 2, 3)
    base = docentes_por_trim.get(2) or docentes_por_trim.get(1) or docentes_por_trim.get(3) or []
    clave = lambda d: A.norm(d["docente"]).strip()
    por_t = {t: {clave(d): d for d in docentes_por_trim.get(t, [])} for t in trims}
    ult = {t: _ultimos(resultados, t) for t in trims}
    revs = {t: {} for t in trims}
    for t in trims:
        for (d, ins), r in ult[t].items():
            revs[t].setdefault(d, {})[ins] = r
    con_datos = {t: any(d["estado"] != "sin_entrega" for d in docentes_por_trim.get(t, [])) or bool(revs[t]) for t in trims}

    wb = Workbook(); ws = wb.active; ws.title = "Control de entrega"
    ws.append(["CONTROL DE ENTREGA DE PLANEACIONES — CICLO %s" % cfg["ciclo"]]); ws["A1"].font = Font(bold=True, size=13)
    ws.append([""] * 4 + sum(([("%s TRIMESTRE" % TRIM[t])] + [""] * 3 for t in trims), []))
    _head(ws, 3, ["Campo formativo", "N.º", "Docente", "Disciplina"] + ["Archivos", "Revisión realizada", "Estado", "Nota"] * 3,
          [24, 6, 38, 22] + [10, 20, 16, 34] * 3)
    colores = {"Entregó": "CDEAD2", "Solo otros archivos": "FCE8B2", "Sin entrega": "F4C7C3"}
    tonos = {1: "1F3864", 2: "2E5597", 3: "1F6F5C"}
    for k, t in enumerate(trims):
        c0 = 5 + 4 * k
        ws.merge_cells(start_row=2, start_column=c0, end_row=2, end_column=c0 + 3)
        c = ws.cell(2, c0); c.font = Font(bold=True, color="FFFFFF"); c.fill = PatternFill("solid", fgColor=tonos[t]); c.alignment = Alignment(horizontal="center")
        for cc in range(c0, c0 + 4):
            ws.cell(2, cc).fill = PatternFill("solid", fgColor=tonos[t])
    ent = {t: 0 for t in trims}
    for d in base:
        k0 = clave(d)
        disc = ""
        for t in trims:
            disc = disc or next((r.get("disciplina") for r in revs[t].get(k0, {}).values() if r.get("disciplina")), "")
        disc = disc or disciplina_sugerida(d["campo"], d["num"])
        fila = [d["campo"].replace("CAMPO ", "").title(), d["num"] or "—", d["docente"].title(), disc]
        estados = {}
        for t in trims:
            dt = por_t[t].get(k0)
            rv = revs[t].get(k0, {})
            rev_txt = " + ".join({"plano": "Plano didáctico", "guia_pa": "Programa analítico"}[k] for k in ("plano", "guia_pa") if k in rv)
            if not con_datos[t] or dt is None:
                fila += ["—", "", "—", ""]; estados[t] = None; continue
            est = "Entregó" if dt["estado"] == "listo" else ("Solo otros archivos" if dt["estado"] == "solo_otros" else "Sin entrega")
            ent[t] += est == "Entregó"
            nota = []
            if dt.get("suelto"):
                nota.append("Archivos sueltos (sin carpeta de trimestre)")
            if est == "Solo otros archivos":
                nota.append("No hay planeación; solo " + ", ".join(a["name"] for a in dt["archivos"][:2]))
            fila += [len([a for a in dt["archivos"] if a["tipo"] != "otro"]), rev_txt, est, "; ".join(nota)]
            estados[t] = est
        ws.append(fila)
        row = ws.max_row
        for c in ws[row]:
            c.border = BORDE; c.alignment = Alignment(vertical="center", wrap_text=True)
        for k, t in enumerate(trims):
            c0 = 5 + 4 * k
            ws.cell(row, c0).alignment = Alignment(horizontal="center", vertical="center")
            if estados.get(t):
                ws.cell(row, c0 + 2).fill = PatternFill("solid", fgColor=colores[estados[t]])
            else:
                ws.cell(row, c0 + 2).font = Font(color="888888"); ws.cell(row, c0 + 2).alignment = Alignment(horizontal="center", vertical="center")
        ws.cell(row, 2).alignment = Alignment(horizontal="center", vertical="center")
    ws.freeze_panes = "E4"; ws.auto_filter.ref = "A3:P%d" % ws.max_row
    ws.append([])
    for t in trims:
        ws.append(["Resumen %s trimestre" % TRIM[t].lower(),
                   ("%d docentes en carpeta · %d entregaron · %d sin entrega o solo con otros archivos" % (len(base), ent[t], len(base) - ent[t])) if con_datos[t] else "Sin información todavía"])
        ws.cell(ws.max_row, 1).font = Font(bold=True)

    for t in trims:
        hay = [(d, ins, r) for d in base for ins, r in sorted(revs[t].get(clave(d), {}).items()) if ins in ("plano", "guia_pa")]
        if not hay:
            continue
        w2 = wb.create_sheet("Hallazgos %dT" % t)
        _head(w2, 1, ["Docente", "Instrumento", "Disciplina", "Datos de identificación a corregir", "Resultado (oportunidad / fortaleza)", "Principales observaciones", "Archivos revisados"], [30, 18, 18, 46, 24, 80, 40])
        for d, ins, r in hay:
            prob, res, obs = _fila_hallazgo(r, ins)
            w2.append([d["docente"].title(), "Plano didáctico" if ins == "plano" else "Programa analítico", r.get("disciplina", ""), prob, res, obs, "; ".join(r.get("archivos", []))])
        for row in w2.iter_rows(min_row=2):
            for c in row:
                c.alignment = Alignment(wrap_text=True, vertical="top"); c.border = BORDE
        w2.freeze_panes = "A2"

    obs_all = [(t, r) for t in trims for r in _ultimos_obs(resultados, t)]
    if obs_all:
        w3 = wb.create_sheet("Observaciones de clase")
        _head(w3, 1, ["Trim.", "Docente", "Fecha", "Grado y grupo", "Dim. 1 Currículo", "Dim. 2 Ambiente", "Dim. 3 Estrategias", "Dim. 4 Evaluación", "Observaciones"], [7, 30, 14, 14, 26, 26, 26, 26, 70])
        for t, r in obs_all:
            c = conteo_obs(r)
            w3.append(["%dT" % t, r["docente"].title(), r.get("fecha", ""), r.get("grado", "")] +
                      ["RA %(RA)d · EP %(EP)d · L %(L)d · D %(D)d · NO %(NO)d" % x["n"] if x["marcados"] else "Sin registrar" for x in c] +
                      [(r.get("observaciones") or "").replace("\n", " ")])
        for row in w3.iter_rows(min_row=2):
            for cell in row:
                cell.alignment = Alignment(wrap_text=True, vertical="top"); cell.border = BORDE
        w3.freeze_panes = "A2"
    aula_all = [(t, r) for t in trims for r in _ultimos_obs(resultados, t, "aula")]
    if aula_all:
        w4 = wb.create_sheet("Guía de observación en aula")
        _head(w4, 1, ["Trim.", "Docente", "Fecha", "Grado y grupo", "Disciplina", "Generalidades", "Estrategias didácticas", "Recursos didácticos",
                      "Organización y desarrollo", "Evaluación", "% SÍ (total)", "Observaciones y recomendaciones"], [7, 30, 14, 12, 18, 18, 18, 18, 18, 18, 12, 80])
        for t, r in aula_all:
            c = conteo_aula(r)
            si = sum(x["n"]["SI"] for x in c); ob = sum(x["n"]["SI"] + x["n"]["NO"] + x["n"]["PM"] for x in c)
            w4.append(["%dT" % t, r["docente"].title(), r.get("fecha", ""), r.get("grado", ""), r.get("disciplina", "")] +
                      ["%d SÍ · %d NO · %d PM · %d NA" % (x["n"]["SI"], x["n"]["NO"], x["n"]["PM"], x["n"]["NA"]) if x["marcados"] else "Sin registrar" for x in c] +
                      ["%d%%" % round(100.0 * si / ob) if ob else "", (r.get("observaciones") or "").replace("\n", " ")])
        for row in w4.iter_rows(min_row=2):
            for cell in row:
                cell.alignment = Alignment(wrap_text=True, vertical="top"); cell.border = BORDE
        w4.freeze_panes = "A2"
    os.makedirs(destino_dir, exist_ok=True)
    out = os.path.join(destino_dir, "RESUMEN REVISION PLANEACIONES - CICLO %s.xlsx" % cfg["ciclo"])
    wb.save(out)
    return out


def _ultimos_obs(resultados, trim, tipo="obs"):
    out = {}
    for mt, r in sorted(resultados, key=lambda x: x[0]):
        if r.get("instrumento") == tipo and int(r.get("trimestre") or 0) == int(trim):
            out[A.norm(r["docente"]).strip()] = r
    return list(out.values())
