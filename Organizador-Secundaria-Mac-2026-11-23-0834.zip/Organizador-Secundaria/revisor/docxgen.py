# -*- coding: utf-8 -*-
"""Genera el formato Word de revisión (Plano Didáctico / Guía de Programa Analítico)."""
import os, datetime
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from rubrics import FACTORES, GUIA_PA, N_REACTIVOS, N_GUIA, OBS_GENERALIDADES, OBS_DIMENSIONES, GUIA_AULA, N_AULA

COL = {1: "F4C7C3", 2: "FCE8B2", 3: "CDEAD2", 4: "9ED8AE"}
GRIS = "E8EAED"
AZUL = "1F3864"
TRIM = {1: "Primer", 2: "Segundo", 3: "Tercer"}
MESES = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"]


def fecha_hoy():
    d = datetime.date.today()
    return "%d de %s de %d" % (d.day, MESES[d.month - 1], d.year)


def shade(cell, hexcolor):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear"); shd.set(qn("w:color"), "auto"); shd.set(qn("w:fill"), hexcolor)
    tcPr.append(shd)


def set_cell(cell, text, bold=False, size=8.5, align=None, color=None, italic=False):
    cell.text = ""
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(0); p.paragraph_format.space_before = Pt(0)
    if align == "c":
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(text); r.bold = bold; r.italic = italic; r.font.size = Pt(size)
    if color:
        r.font.color.rgb = RGBColor.from_string(color)


def widths(table, ws):
    table.autofit = False
    tblPr = table._tbl.tblPr
    if tblPr.find(qn("w:tblLayout")) is None:
        lay = OxmlElement("w:tblLayout"); lay.set(qn("w:type"), "fixed"); tblPr.append(lay)
    for i, gc in enumerate(table._tbl.tblGrid.findall(qn("w:gridCol"))):
        gc.set(qn("w:w"), str(int(ws[i] * 567)))
    for i, w in enumerate(ws):
        table.columns[i].width = Cm(w)
    for row in table.rows:
        tcs = row._tr.findall(qn("w:tc"))
        if len(tcs) == len(ws):
            for i, w in enumerate(ws):
                row.cells[i].width = Cm(w)
        else:
            for tc in tcs:
                tcPr = tc.get_or_add_tcPr()
                tcW = tcPr.find(qn("w:tcW"))
                if tcW is None:
                    tcW = OxmlElement("w:tcW"); tcPr.append(tcW)
                tcW.set(qn("w:type"), "dxa"); tcW.set(qn("w:w"), str(int(sum(ws) * 567)))


def borders(table):
    b = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        e = OxmlElement("w:" + edge)
        e.set(qn("w:val"), "single"); e.set(qn("w:sz"), "4"); e.set(qn("w:space"), "0"); e.set(qn("w:color"), "8A8F98")
        b.append(e)
    table._tbl.tblPr.append(b)


def repeat_header(row):
    h = OxmlElement("w:tblHeader"); h.set(qn("w:val"), "true"); row._tr.get_or_add_trPr().append(h)


def no_split(row):
    c = OxmlElement("w:cantSplit"); c.set(qn("w:val"), "true"); row._tr.get_or_add_trPr().append(c)


def para(doc, text, bold=False, size=10, align=None, color=None, space_after=2, italic=False):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(space_after); p.paragraph_format.space_before = Pt(0)
    if align == "c":
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(text); r.bold = bold; r.italic = italic; r.font.size = Pt(size)
    if color:
        r.font.color.rgb = RGBColor.from_string(color)
    return p


def heading(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(10); p.paragraph_format.space_after = Pt(3)
    p.paragraph_format.keep_with_next = True
    r = p.add_run(text); r.bold = True; r.font.size = Pt(11); r.font.color.rgb = RGBColor.from_string(AZUL)
    pb = OxmlElement("w:pBdr"); bt = OxmlElement("w:bottom")
    bt.set(qn("w:val"), "single"); bt.set(qn("w:sz"), "6"); bt.set(qn("w:space"), "1"); bt.set(qn("w:color"), AZUL)
    pb.append(bt); p._p.get_or_add_pPr().append(pb)


def bullet(doc, text, size=9.5):
    p = doc.add_paragraph(style="List Bullet"); p.paragraph_format.space_after = Pt(1)
    p.add_run(text).font.size = Pt(size)


def generar(res, cfg, outpath):
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21.59), Cm(27.94)
    sec.left_margin = sec.right_margin = Cm(1.6); sec.top_margin = sec.bottom_margin = Cm(1.4)
    st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(10)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), "Calibri")
    plano = res["instrumento"] == "plano"
    trim = res.get("trimestre")
    trim_txt = (TRIM.get(trim, str(trim)) + " trimestre") if trim else ""

    para(doc, "Secretaría de Educación del Gobierno del Estado de Yucatán", True, 11, "c", space_after=0)
    para(doc, "Dirección de Educación Secundaria", False, 10, "c", space_after=0)
    para(doc, "Supervisión Secundarias Federales · Zona %s · CCT %s" % (cfg.get("zona", ""), cfg["cct"]), False, 10, "c", space_after=4)
    para(doc, "INSTRUMENTO PARA LA REVISIÓN DEL PLANO DIDÁCTICO" if plano else "GUÍA PARA EL ANÁLISIS DE PROGRAMA ANALÍTICO", True, 14, "c", color=AZUL, space_after=0)
    para(doc, "%s · Ciclo escolar %s" % (trim_txt, cfg["ciclo"]), False, 10, "c", space_after=6)

    t = doc.add_table(rows=0, cols=4); borders(t)
    for a, b, c, e in [
        ("Nombre de la escuela", cfg["escuela"], "C.C.T.", cfg["cct"]),
        ("Campo formativo", res.get("campo", ""), "Disciplina", res.get("disciplina", "")),
        ("Docente", res["docente"], "Grado y grupo", res.get("grado", "")),
        ("Acompañante / revisor(a)", res.get("revisor", ""), "Lugar y fecha", fecha_hoy()),
    ]:
        r = t.add_row()
        for i, (txt, bold) in enumerate([(a, True), (b, False), (c, True), (e, False)]):
            set_cell(r.cells[i], txt, bold=bold, size=9)
            if bold:
                shade(r.cells[i], GRIS)
    widths(t, [3.6, 6.4, 2.8, 5.6])

    para(doc, "", space_after=2)
    t = doc.add_table(rows=2, cols=2); borders(t)
    set_cell(t.rows[0].cells[0], "Estado de la entrega", True, 9); shade(t.rows[0].cells[0], GRIS)
    set_cell(t.rows[0].cells[1], res.get("estado", ""), True, 9); shade(t.rows[0].cells[1], "FCE8B2")
    set_cell(t.rows[1].cells[0], "Archivos revisados", True, 9); shade(t.rows[1].cells[0], GRIS)
    set_cell(t.rows[1].cells[1], "\n".join("• " + a for a in res.get("archivos", [])), size=8.5)
    widths(t, [3.6, 14.8])

    if res.get("resumen"):
        para(doc, "", space_after=2)
        t = doc.add_table(rows=1, cols=2); borders(t)
        set_cell(t.rows[0].cells[0], "Resumen", True, 9); shade(t.rows[0].cells[0], GRIS)
        set_cell(t.rows[0].cells[1], res["resumen"], size=9)
        widths(t, [3.6, 14.8])

    heading(doc, "A. Verificación de datos de identificación (escuela, CCT, ciclo…)")
    t = doc.add_table(rows=1, cols=3); borders(t)
    for i, h in enumerate(["Elemento", "", "Lo que se encontró en el documento"]):
        set_cell(t.rows[0].cells[i], h, True, 9, "c" if i == 1 else None, color="FFFFFF"); shade(t.rows[0].cells[i], AZUL)
    repeat_header(t.rows[0])
    sym = {"ok": ("✔", "CDEAD2"), "no": ("✘", "F4C7C3"), "warn": ("⚠", "FCE8B2")}
    for el, tipo, obs in res["identificacion"]:
        r = t.add_row(); no_split(r)
        set_cell(r.cells[0], el, True, 8.5)
        s, c = sym.get(tipo, sym["warn"])
        set_cell(r.cells[1], s, True, 11, "c"); shade(r.cells[1], c)
        set_cell(r.cells[2], obs, size=8.5)
    widths(t, [3.6, 1.0, 13.8])
    para(doc, "✔ correcto   ⚠ por aclarar / incompleto   ✘ incorrecto o ausente", size=8, italic=True, space_after=2)

    if plano:
        heading(doc, "B. Instrumento de revisión del Plano Didáctico")
        para(doc, "Nivel de valoración: I y II = área de oportunidad (I no cumple · II cumple parcialmente) · III y IV = área de fortaleza (III cumple correcta y completamente · IV de manera extraordinaria) · NA = no aplica.", size=8, italic=True, space_after=3)
        t = doc.add_table(rows=1, cols=8); borders(t)
        for i, h in enumerate(["#", "Reactivo", "I", "II", "III", "IV", "NA", "Observaciones"]):
            set_cell(t.rows[0].cells[i], h, True, 8.5, "c" if i in (0, 2, 3, 4, 5, 6) else None, color="FFFFFF"); shade(t.rows[0].cells[i], AZUL)
        repeat_header(t.rows[0])
        k = 0
        cnt = {0: 0, 1: 0, 2: 0, 3: 0, 4: 0}
        for ftitle, items in FACTORES:
            r = t.add_row(); m = r.cells[0].merge(r.cells[7])
            set_cell(m, ftitle, True, 9); shade(m, GRIS)
            for j, it in enumerate(items, 1):
                lvl, obs = res["niveles"][k]; lvl = int(lvl); k += 1; cnt[lvl] += 1
                r = t.add_row(); no_split(r)
                set_cell(r.cells[0], str(j), size=8.5, align="c")
                set_cell(r.cells[1], it, size=8.5)
                for c, L in zip(range(2, 6), (1, 2, 3, 4)):
                    if lvl == L:
                        set_cell(r.cells[c], "X", True, 10, "c"); shade(r.cells[c], COL[L])
                    else:
                        set_cell(r.cells[c], "", size=8)
                if lvl == 0:
                    set_cell(r.cells[6], "", size=8)
                set_cell(r.cells[7], obs, size=8)
        widths(t, [0.6, 4.4, 0.75, 0.75, 0.85, 0.75, 0.75, 9.55])
        para(doc, "", space_after=2)
        tt = doc.add_table(rows=2, cols=4); borders(tt)
        for i, (lab, L) in enumerate([("Nivel I", 1), ("Nivel II", 2), ("Nivel III", 3), ("Nivel IV", 4)]):
            set_cell(tt.rows[0].cells[i], lab, True, 9, "c"); shade(tt.rows[0].cells[i], COL[L])
            set_cell(tt.rows[1].cells[i], "%d de %d reactivos" % (cnt[L], N_REACTIVOS), False, 9, "c")
        widths(tt, [4.6] * 4)
        if cnt[0] == N_REACTIVOS:
            para(doc, "Niveles sin asignar (completar manualmente).", True, 9, space_after=2)
        else:
            para(doc, "Áreas de oportunidad: %d reactivos (I-II) · Áreas de fortaleza: %d reactivos (III-IV)." % (cnt[1] + cnt[2], cnt[3] + cnt[4]), True, 9, space_after=2)
    else:
        heading(doc, "B. Guía para el análisis del Programa Analítico")
        para(doc, "Marca (X) si se aprecia con claridad el componente. SÍ / NO / N/A.", size=8, italic=True, space_after=3)
        t = doc.add_table(rows=1, cols=5); borders(t)
        for i, h in enumerate(["INDICADOR", "SÍ", "NO", "N/A", "Observaciones"]):
            set_cell(t.rows[0].cells[i], h, True, 8.5, "c" if i in (1, 2, 3) else None, color="FFFFFF"); shade(t.rows[0].cells[i], AZUL)
        repeat_header(t.rows[0])
        k = 0; cn = {"SI": 0, "NO": 0, "NA": 0, "": 0}
        for secname, items in GUIA_PA:
            r = t.add_row(); m = r.cells[0].merge(r.cells[4]); set_cell(m, secname, True, 9); shade(m, GRIS)
            for it in items:
                marca, obs = res["guia"][k]; k += 1; cn[marca] += 1
                r = t.add_row(); no_split(r)
                set_cell(r.cells[0], it, size=8.5)
                for c, mm in zip((1, 2, 3), ("SI", "NO", "NA")):
                    if marca == mm:
                        set_cell(r.cells[c], "X", True, 10, "c"); shade(r.cells[c], {"SI": "CDEAD2", "NO": "F4C7C3", "NA": GRIS}[mm])
                    else:
                        set_cell(r.cells[c], "", size=8)
                set_cell(r.cells[4], obs, size=8)
        widths(t, [4.8, 0.8, 0.8, 0.9, 11.1])
        para(doc, "", space_after=2)
        para(doc, "Resumen: SÍ %d · NO %d · N/A %d%s (de %d indicadores)." % (cn["SI"], cn["NO"], cn["NA"], (" · sin marcar %d" % cn[""]) if cn[""] else "", N_GUIA), True, 9)

    heading(doc, "C. Observaciones generales")
    for o in res.get("otras", []):
        bullet(doc, o)
    if not res.get("otras"):
        para(doc, "Sin observaciones adicionales.", size=9.5)
    heading(doc, "D. Acuerdos y tareas para el docente")
    for tt_ in res.get("tareas", []):
        p = doc.add_paragraph(style="List Number"); p.paragraph_format.space_after = Pt(1)
        p.add_run(tt_).font.size = Pt(9.5)
    para(doc, "", space_after=2)
    para(doc, "Fecha límite para entregar las correcciones: ____________________", size=9.5, space_after=10)
    t = doc.add_table(rows=2, cols=2)
    for i, lab in enumerate(["Acompañante / revisor(a)", "Docente: %s (enterado)" % res["docente"].title()]):
        set_cell(t.rows[0].cells[i], "\n\n______________________________", size=9, align="c")
        set_cell(t.rows[1].cells[i], lab, True, 9, "c")
    widths(t, [9.2, 9.2])
    para(doc, "", space_after=2)
    para(doc, "Revisión documental realizada el %s%s. Las valoraciones deben ser validadas por la dirección. Instrumento: Anexo 4.1 Revisión del Plano Didáctico / Guía para el análisis de Programa Analítico (Supervisión Secundarias Federales)."
         % (fecha_hoy(), " con apoyo de IA" if res.get("ia") else ""), size=7.5, italic=True)
    os.makedirs(os.path.dirname(outpath), exist_ok=True)
    doc.save(outpath)
    return outpath


# ---------------------------------------------------------------------------
def conteo_obs(res):
    """Por dimensión: conteos por nivel y porcentajes sobre lo observado (sin «NO»)."""
    out = []
    for d, (_, items) in enumerate(OBS_DIMENSIONES):
        marks = (res.get("dims") or [[""] * len(i) for _, i in OBS_DIMENSIONES])[d]
        c = {k: 0 for k in ("RA", "EP", "L", "D", "NO")}
        for m in marks:
            if m in c:
                c[m] += 1
        obs = c["RA"] + c["EP"] + c["L"] + c["D"]
        pct = {k: (round(100.0 * c[k] / obs) if obs else 0) for k in ("RA", "EP", "L", "D")}
        pct["NO"] = round(100.0 * c["NO"] / len(items)) if items else 0
        out.append({"n": c, "pct": pct, "marcados": obs + c["NO"], "total": len(items)})
    return out


def generar_obs(res, cfg, outpath):
    """Formato «Observación de la intervención didáctica»."""
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21.59), Cm(27.94)
    sec.left_margin = sec.right_margin = Cm(1.6); sec.top_margin = sec.bottom_margin = Cm(1.4)
    st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(10)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), "Calibri")
    trim = res.get("trimestre")
    trim_txt = (TRIM.get(trim, str(trim)) + " trimestre") if trim else ""

    para(doc, "Secretaría de Educación del Gobierno del Estado de Yucatán", True, 11, "c", space_after=0)
    para(doc, "Dirección de Educación Secundaria", False, 10, "c", space_after=0)
    para(doc, "Supervisión Secundarias Federales · Zona %s · CCT %s" % (cfg.get("zona", ""), cfg["cct"]), False, 10, "c", space_after=4)
    para(doc, "OBSERVACIÓN DE LA INTERVENCIÓN DIDÁCTICA", True, 14, "c", color=AZUL, space_after=0)
    para(doc, "%s · Ciclo escolar %s" % (trim_txt, cfg["ciclo"]), False, 10, "c", space_after=6)

    t = doc.add_table(rows=0, cols=4); borders(t)
    for a, b, c, e in [
        ("CCT", cfg["cct"], "Turno", res.get("turno", "")),
        ("Nivel", res.get("nivel", ""), "Modalidad", res.get("modalidad", "")),
        ("Docente", res["docente"], "Grado y grupo", res.get("grado", "")),
        ("Disciplina / campo", " / ".join(x for x in (res.get("disciplina", ""), res.get("campo", "")) if x), "Fecha", res.get("fecha") or fecha_hoy()),
        ("Observador(a)", res.get("revisor", ""), "Escuela", cfg["escuela"]),
    ]:
        r = t.add_row()
        for i, (txt, bold) in enumerate([(a, True), (b, False), (c, True), (e, False)]):
            set_cell(r.cells[i], txt, bold=bold, size=9)
            if bold:
                shade(r.cells[i], GRIS)
    widths(t, [3.3, 6.0, 2.8, 6.3])

    if res.get("previo"):
        para(doc, "", space_after=2)
        t = doc.add_table(rows=1, cols=2); borders(t)
        set_cell(t.rows[0].cells[0], "De la revisión de su planeación", True, 9); shade(t.rows[0].cells[0], GRIS)
        set_cell(t.rows[0].cells[1], res["previo"], size=8.5)
        widths(t, [3.6, 14.8])

    heading(doc, "Generalidades")
    t = doc.add_table(rows=1, cols=7); borders(t)
    for i, h in enumerate(["#", "Aspecto", "SÍ", "NO", "Puede mejorar", "NA", "Observaciones"]):
        set_cell(t.rows[0].cells[i], h, True, 8, "c" if i in (0, 2, 3, 4, 5) else None, color="FFFFFF"); shade(t.rows[0].cells[i], AZUL)
    repeat_header(t.rows[0])
    gcol = {"SI": "CDEAD2", "NO": "F4C7C3", "PM": "FCE8B2", "NA": GRIS}
    for i, txt in enumerate(OBS_GENERALIDADES):
        val, obs = (res.get("generalidades") or [["", ""]] * len(OBS_GENERALIDADES))[i]
        r = t.add_row(); no_split(r)
        set_cell(r.cells[0], str(i + 1), size=8.5, align="c"); set_cell(r.cells[1], txt, size=8.5)
        for c, k in zip(range(2, 6), ("SI", "NO", "PM", "NA")):
            if val == k:
                set_cell(r.cells[c], "X", True, 10, "c"); shade(r.cells[c], gcol[k])
            else:
                set_cell(r.cells[c], "", size=8)
        set_cell(r.cells[6], obs, size=8)
        crop = ((res.get("crops") or {}).get("gen") or [""] * 7)[i]
        if crop and not obs:
            try:
                import base64, io
                r.cells[6].paragraphs[0].add_run().add_picture(io.BytesIO(base64.b64decode(crop)), width=Cm(7.2))
            except Exception:
                pass
    widths(t, [0.6, 6.0, 0.8, 0.8, 1.4, 0.8, 8.0])

    para(doc, "", space_after=2)
    para(doc, "Niveles de desempeño: RA = Requiere apoyo (no se relaciona con el descriptor o está ausente) · EP = En proceso (se relaciona parcialmente, requiere mejorar) · "
              "L = Logrado (se relaciona completamente) · D = Destacado (se relaciona completamente y presenta propuestas o ideas innovadoras) · NO = no susceptible de observarse.",
         size=8, italic=True, space_after=2)
    cont = conteo_obs(res)
    ncol = {"RA": "F4C7C3", "EP": "FCE8B2", "L": "CDEAD2", "D": "9ED8AE", "NO": GRIS}
    for d, (dname, items) in enumerate(OBS_DIMENSIONES):
        heading(doc, dname)
        t = doc.add_table(rows=1, cols=7); borders(t)
        for i, h in enumerate(["#", "Descriptor", "RA", "EP", "L", "D", "NO"]):
            set_cell(t.rows[0].cells[i], h, True, 8.5, "c" if i != 1 else None, color="FFFFFF"); shade(t.rows[0].cells[i], AZUL)
        repeat_header(t.rows[0])
        marks = (res.get("dims") or [[""] * len(i) for _, i in OBS_DIMENSIONES])[d]
        for j, txt in enumerate(items):
            r = t.add_row(); no_split(r)
            set_cell(r.cells[0], str(j + 1), size=8.5, align="c"); set_cell(r.cells[1], txt, size=8.5)
            for c, k in zip(range(2, 7), ("RA", "EP", "L", "D", "NO")):
                if marks[j] == k:
                    set_cell(r.cells[c], "X", True, 10, "c"); shade(r.cells[c], ncol[k])
                else:
                    set_cell(r.cells[c], "", size=8)
        for lab, key in (("Subtotal", "n"), ("Porcentaje", "pct")):
            r = t.add_row()
            set_cell(r.cells[0], "", size=8); set_cell(r.cells[1], lab, True, 8.5); shade(r.cells[1], GRIS)
            for c, k in zip(range(2, 7), ("RA", "EP", "L", "D", "NO")):
                v = cont[d][key][k]
                set_cell(r.cells[c], (str(v) + ("%" if key == "pct" else "")) if cont[d]["marcados"] else "", True, 8.5, "c"); shade(r.cells[c], GRIS)
        widths(t, [0.6, 10.6, 1.4, 1.4, 1.4, 1.4, 1.4])
    para(doc, "Subtotal = número de enunciados marcados en cada nivel. Porcentaje = ese número entre los enunciados observados de la dimensión (en «NO», entre el total de enunciados).", size=7.5, italic=True, space_after=2)

    heading(doc, "OBSERVACIONES")
    texto = (res.get("observaciones") or "").strip()
    crop_obs = (res.get("crops") or {}).get("obs") or ""
    if crop_obs and not texto:
        try:
            import base64, io
            doc.add_picture(io.BytesIO(base64.b64decode(crop_obs)), width=Cm(18.2))
        except Exception:
            pass
    elif texto:
        for ln in texto.split("\n"):
            para(doc, ln, size=9.5, space_after=1)
    else:
        for _ in range(8):
            para(doc, "_" * 98, size=9, space_after=4)
    para(doc, "", space_after=8)
    t = doc.add_table(rows=2, cols=2)
    for i, lab in enumerate(["Observador(a)", "Docente: %s (enterado)" % res["docente"].title()]):
        set_cell(t.rows[0].cells[i], "\n\n______________________________", size=9, align="c")
        set_cell(t.rows[1].cells[i], lab, True, 9, "c")
    widths(t, [9.2, 9.2])
    para(doc, "", space_after=2)
    para(doc, "Instrumento: Observación de la Intervención Didáctica (Supervisión Secundarias Federales). Valoraciones registradas por quien observa la clase.", size=7.5, italic=True)
    os.makedirs(os.path.dirname(outpath), exist_ok=True)
    doc.save(outpath)
    return outpath


# ---------------------------------------------------------------------------------------------------------------
def conteo_aula(res):
    """Por sección de la Guía de Observación en el Aula: cuántos SI / NO / Puede mejorar / NA y % de SI sobre lo observado."""
    marks = [m[0] if m else "" for m in (res.get("aula") or [])] + [""] * N_AULA
    out, k = [], 0
    for nombre, items in GUIA_AULA:
        c = {"SI": 0, "NO": 0, "PM": 0, "NA": 0}
        for _ in items:
            if marks[k] in c:
                c[marks[k]] += 1
            k += 1
        obs = c["SI"] + c["NO"] + c["PM"]
        out.append({"seccion": nombre, "n": c, "total": len(items), "marcados": obs + c["NA"], "pct_si": round(100.0 * c["SI"] / obs) if obs else 0})
    return out


def generar_aula(res, cfg, outpath):
    """Formato «Guía de Observación en el Aula para Evaluar al Docente» (el de la escuela), listo para imprimir."""
    import base64, io
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21.59), Cm(27.94)
    sec.left_margin = sec.right_margin = Cm(1.5); sec.top_margin = sec.bottom_margin = Cm(1.3)
    st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(10)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), "Calibri")

    para(doc, "Guía de Observación en el Aula para Evaluar al Docente", True, 11, "c", space_after=6)
    fecha = res.get("fecha") or fecha_hoy()
    filas = [
        [("Escuela Secundaria General: ", cfg["escuela"]), ("CCT: ", cfg["cct"])],
        [("Fecha: ", fecha), ("Grado y Grupo: ", res.get("grado", "")), ("Disciplina: ", res.get("disciplina", ""))],
        [("Nombre del Docente: ", res["docente"])],
        [("Nombre del Observador(a): ", res.get("revisor", ""))],
    ]
    for fila in filas:
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2); p.paragraph_format.space_before = Pt(0)
        for j, (et, val) in enumerate(fila):
            if j:
                p.add_run("      ")
            r = p.add_run(et); r.font.size = Pt(9.5)
            r = p.add_run(val); r.font.size = Pt(9.5); r.bold = True
    para(doc, "A continuación, encontrará una serie de enunciados que describen diferentes aspectos de la práctica pedagógica dentro del aula. "
              "Marque con una “X” la opción que corresponda a su percepción del desempeño observado en el docente.", False, 9, space_after=3)

    t = doc.add_table(rows=0, cols=7); borders(t)
    h = t.add_row(); repeat_header(h)
    h.cells[0].merge(h.cells[1])
    for cel, txt in ((h.cells[0], "INDICADORES"), (h.cells[2], "SI"), (h.cells[3], "NO"), (h.cells[4], "Puede Mejorar"), (h.cells[5], "NA"), (h.cells[6], "Observaciones")):
        set_cell(cel, txt, True, 8.5, "c", "FFFFFF"); shade(cel, "000000")
    marks = (res.get("aula") or [])
    crops = (res.get("crops") or {}).get("aula") or [""] * N_AULA
    col = {"SI": 2, "NO": 3, "PM": 4, "NA": 5}
    k = 0
    for nombre, items in GUIA_AULA:
        r = t.add_row(); no_split(r)
        r.cells[0].merge(r.cells[6])
        set_cell(r.cells[0], nombre, True, 9); shade(r.cells[0], "D9D9D9")
        for it in items:
            r = t.add_row(); no_split(r)
            m = marks[k] if k < len(marks) and marks[k] else ["", ""]
            val, obs = (m[0], (m[1] if len(m) > 1 else "")) if isinstance(m, (list, tuple)) else (m, "")
            set_cell(r.cells[0], str(k + 1), True, 8.5, "c")
            set_cell(r.cells[1], it, False, 8.5)
            for c in col.values():
                set_cell(r.cells[c], "", False, 9, "c")
            if val in col:
                set_cell(r.cells[col[val]], "X", True, 11, "c")
            set_cell(r.cells[6], (obs or "").strip(), False, 8)
            cr = crops[k] if k < len(crops) else ""
            if cr and not (obs or "").strip():
                try:
                    r.cells[6].paragraphs[0].add_run().add_picture(io.BytesIO(base64.b64decode(cr)), width=Cm(4.7))
                except Exception:
                    pass
            k += 1
    widths(t, [0.8, 8.2, 1.0, 1.0, 1.7, 1.0, 4.9])

    p = para(doc, "OBSERVACIONES Y RECOMENDACIONES:", True, 10, space_after=4)
    p.paragraph_format.space_before = Pt(10); p.paragraph_format.keep_with_next = True
    texto = (res.get("observaciones") or "").strip()
    for ln in texto.split("\n"):
        pp = para(doc, ln, False, 10, space_after=4)
        pp.paragraph_format.line_spacing = 1.1
    if not texto:
        for _ in range(4):
            para(doc, " ", size=10, space_after=6)
    para(doc, "", space_after=14)
    para(doc, "______________________________________", False, 10, "c", space_after=0)
    para(doc, "RESPONSABLE DE LA EVALUACIÓN", True, 9, "c", space_after=0)
    if res.get("revisor"):
        para(doc, res["revisor"], False, 9, "c", space_after=0)
    doc.save(outpath)
