# -*- coding: utf-8 -*-
"""Lectura de la «Observación de la intervención didáctica» llenada a mano (escaneo o fotografía) y
llenado del PDF oficial con los resultados.

Funciona sin internet y sin IA: alinea la imagen con el formato oficial (plantillas/observacion_oficial.pdf)
y detecta qué casilla tiene tinta nueva (palomeada con pluma o lápiz). Siempre debe revisarse en pantalla.
"""
import os, io, base64, subprocess, tempfile, textwrap
import numpy as np
import cv2
import fitz

HERE = os.path.dirname(os.path.abspath(__file__))
PLANTILLA = os.path.join(HERE, "plantillas", "observacion_oficial.pdf")
DPI = 150
S = DPI / 72.0
GEN_COLS = ("SI", "NO", "PM", "NA")
DIM_COLS = ("RA", "EP", "L", "D", "NO")
N_ITEMS = (6, 8, 9, 6)            # enunciados por dimensión (la 2 continúa en la hoja 2)
UMBRAL = 40                       # píxeles de tinta nueva para considerar una casilla marcada
_CACHE = {}


# ------------------------------------------------------------------ plantilla
def _render():
    d = fitz.open(PLANTILLA)
    out = []
    for pi in (0, 1):
        pix = d[pi].get_pixmap(dpi=DPI, colorspace=fitz.csGRAY)
        out.append(np.frombuffer(pix.samples, np.uint8).reshape(pix.h, pix.w).copy())
    return d, out


def _celdas(g):
    inv = (g < 170).astype(np.uint8) * 255
    h = cv2.morphologyEx(inv, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (30, 1)))
    v = cv2.morphologyEx(inv, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (1, 20)))
    grid = cv2.dilate(cv2.bitwise_or(h, v), np.ones((3, 3), np.uint8))
    n, _, st, _ = cv2.connectedComponentsWithStats(cv2.bitwise_not(grid), connectivity=4)
    return [tuple(int(x) for x in st[i][:4]) for i in range(1, n) if 25 < st[i][2] < 1000 and 18 < st[i][3] < 250]


def _filas(cells, tol=6):
    cells = sorted(cells, key=lambda c: (c[1], c[0]))
    rows = []
    for c in cells:
        if rows and abs(rows[-1][0][1] - c[1]) <= tol:
            rows[-1].append(c)
        else:
            rows.append([c])
    for r in rows:
        r.sort(key=lambda c: c[0])
    return rows


def _bloque(celdas, x_izq, y0, y1, n_max):
    """Filas de 5 casillas consecutivas desde y0; luego las 2 filas anchas (Subtotal, Porcentaje)."""
    cs = [c for c in celdas if c[0] >= x_izq and y0 <= c[1] <= y1]
    rows = _filas(cs)
    datos, extra = [], []
    for r in rows:
        if len(r) == 5 and not extra and len(datos) < n_max and all(c[2] < 140 for c in r):
            datos.append(r)
        elif len(r) == 1 and datos:
            extra.append(r[0])
    return datos, extra[:2]


def geometria():
    """Casillas de la plantilla oficial (en píxeles a 150 dpi, por hoja)."""
    if "geo" in _CACHE:
        return _CACHE["geo"]
    d, gs = _render()
    cel = [_celdas(g) for g in gs]
    # --- generalidades (hoja 0)
    gen = [c for c in cel[0] if c[0] >= 335 * S and 169 * S <= c[1] <= 292 * S]
    filas = [r for r in _filas(gen) if len(r) == 5]
    if len(filas) != 7:
        raise RuntimeError("La plantilla oficial no tiene el formato esperado (generalidades).")
    # --- encabezados RA de cada bloque
    ras = []
    for pi in (0, 1):
        for w in d[pi].get_text("words"):
            if w[4] == "RA" and w[0] > 380:
                ras.append((pi, w[0], w[1]))
    ras.sort(key=lambda t: (t[0], t[2]))
    if len(ras) != 4:
        raise RuntimeError("La plantilla oficial no tiene el formato esperado (dimensiones).")
    dims = [[] for _ in range(4)]
    sub = [None] * 4
    # dim 1 y dim 2 (parte hoja 0)
    for k in (0, 1):
        pi, x, y = ras[k]
        datos, extra = _bloque(cel[pi], (x - 16) * S, (y + 18) * S, 792 * S, N_ITEMS[k])
        dims[k] += [{"p": pi, "cells": r} for r in datos]
        if extra:
            sub[k] = {"p": pi, "sub": extra[0], "pct": extra[1] if len(extra) > 1 else None}
    # dim 2 continúa en hoja 1 (arriba de la cabecera de la dim 3)
    pi3, x3, y3 = ras[2]
    xl = (ras[1][1] - 16) * S
    datos, extra = _bloque(cel[1], xl, 0, (y3 - 4) * S, N_ITEMS[1] - len(dims[1]))
    dims[1] += [{"p": 1, "cells": r} for r in datos]
    if extra:
        sub[1] = {"p": 1, "sub": extra[0], "pct": extra[1] if len(extra) > 1 else None}
    for k in (2, 3):
        pi, x, y = ras[k]
        datos, extra = _bloque(cel[pi], (x - 16) * S, (y + 18) * S, 792 * S, N_ITEMS[k])
        dims[k] += [{"p": pi, "cells": r} for r in datos]
        if extra:
            sub[k] = {"p": pi, "sub": extra[0], "pct": extra[1] if len(extra) > 1 else None}
    for k in range(4):
        if len(dims[k]) != N_ITEMS[k]:
            raise RuntimeError("La plantilla oficial no tiene el formato esperado (dimensión %d: %d filas)." % (k + 1, len(dims[k])))
    # --- zona de observaciones (hoja 1)
    pg = d[1]
    oy = None
    for w in pg.get_text("words"):
        if w[4].startswith("OBSERVACIONES"):
            oy = w[3]
    rayas = sorted(w[3] for w in pg.get_text("words") if w[4].startswith("____") and oy and w[1] > oy)
    geo = {"gen": filas, "dims": dims, "sub": sub, "obs_y": oy, "rayas": rayas, "tam": [g.shape for g in gs]}
    _CACHE["geo"] = geo
    return geo


def _normalizar(g):
    bg = cv2.morphologyEx(g, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (31, 31)))
    bg = cv2.GaussianBlur(bg, (0, 0), 15)
    return np.clip(g.astype(np.float32) / np.maximum(bg, 1) * 255, 0, 255).astype(np.uint8)


def _plantillas_sift():
    if "sift" in _CACHE:
        return _CACHE["sift"]
    _, gs = _render()
    sift = cv2.SIFT_create(5000)
    out = []
    for g in gs:
        kp, des = sift.detectAndCompute(_normalizar(g), None)
        out.append((kp, des, g))
    _CACHE["sift"] = (sift, out)
    return _CACHE["sift"]


# ------------------------------------------------------------------ entrada
def decodificar(nombre, datos):
    """Devuelve lista de imágenes BGR (un PDF puede traer varias hojas)."""
    ext = os.path.splitext(nombre)[1].lower()
    if ext == ".pdf":
        doc = fitz.open(stream=datos, filetype="pdf")
        imgs = []
        for pg in doc:
            pix = pg.get_pixmap(dpi=200, alpha=False)
            arr = np.frombuffer(pix.samples, np.uint8).reshape(pix.h, pix.w, pix.n)
            imgs.append(cv2.cvtColor(arr, cv2.COLOR_RGB2BGR) if pix.n == 3 else cv2.cvtColor(arr, cv2.COLOR_GRAY2BGR))
        return imgs
    if ext in (".heic", ".heif"):
        with tempfile.TemporaryDirectory() as td:
            src = os.path.join(td, "in" + ext); dst = os.path.join(td, "out.jpg")
            open(src, "wb").write(datos)
            try:
                subprocess.run(["sips", "-s", "format", "jpeg", src, "--out", dst], capture_output=True, timeout=60)
            except FileNotFoundError:   # sips solo existe en Mac: en Windows se pide la foto en JPG
                return []
            if os.path.exists(dst):
                datos = open(dst, "rb").read()
            else:
                return []
    arr = cv2.imdecode(np.frombuffer(datos, np.uint8), cv2.IMREAD_COLOR)
    return [arr] if arr is not None else []


def _mapa(g_norm, ancho):
    """Mapa de tinta suavizado (para comparar páginas y afinar el alineado)."""
    inv = 255 - g_norm
    h, w = inv.shape
    sc = ancho / float(w)
    sm = cv2.resize(inv, (ancho, int(round(h * sc))), interpolation=cv2.INTER_AREA).astype(np.float32)
    return cv2.GaussianBlur(sm, (0, 0), 2.0)


def _quad_papel(img):
    """Esquinas (tl,tr,br,bl) de la hoja de papel en la foto, o None."""
    h, w = img.shape[:2]
    sc = 900.0 / max(h, w)
    sm = cv2.resize(img, None, fx=sc, fy=sc, interpolation=cv2.INTER_AREA)
    g = cv2.GaussianBlur(cv2.cvtColor(sm, cv2.COLOR_BGR2GRAY), (9, 9), 0)
    _, bw = cv2.threshold(g, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    bw = cv2.morphologyEx(bw, cv2.MORPH_CLOSE, np.ones((15, 15), np.uint8))
    cs, _ = cv2.findContours(bw, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not cs:
        return None
    c = max(cs, key=cv2.contourArea)
    if cv2.contourArea(c) < 0.25 * sm.shape[0] * sm.shape[1]:
        return None
    ap = cv2.approxPolyDP(c, 0.02 * cv2.arcLength(c, True), True)
    if len(ap) != 4:
        box = cv2.boxPoints(cv2.minAreaRect(c))
        pts = box
    else:
        pts = ap.reshape(4, 2).astype(np.float32)
    pts = np.array(pts, np.float32) / sc
    # ordenar tl,tr,br,bl
    s_ = pts.sum(1); d_ = np.diff(pts, axis=1).ravel()
    return np.float32([pts[np.argmin(s_)], pts[np.argmin(d_)], pts[np.argmax(s_)], pts[np.argmax(d_)]])


def _ecc(warped, tpl_gray, escala=0.5, iters=120):
    th, tw = tpl_gray.shape
    A = np.diag([escala, escala, 1.0]).astype(np.float64)
    g = _normalizar(cv2.cvtColor(warped, cv2.COLOR_BGR2GRAY))
    a = _mapa(_normalizar(tpl_gray), int(tw * escala))
    b = _mapa(g, int(tw * escala))
    W = np.eye(3, dtype=np.float32)
    try:
        _, W = cv2.findTransformECC(a, b, W, cv2.MOTION_HOMOGRAPHY, (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, iters, 1e-5), None, 5)
    except cv2.error:
        return warped
    Wf = np.linalg.inv(A) @ W.astype(np.float64) @ A
    return cv2.warpPerspective(warped, Wf, (tw, th), flags=cv2.INTER_LINEAR + cv2.WARP_INVERSE_MAP, borderValue=(255, 255, 255))


def alinear(img):
    """Alinea la imagen con la hoja 1 o 2 del formato oficial. Devuelve (hoja, puntaje, imagen_alineada) o None."""
    _, tpls = _plantillas_sift()
    th, tw = tpls[0][2].shape
    cands = []
    # A) imagen completa (escáner), en las 4 rotaciones
    for k in range(4):
        r = np.rot90(img, k).copy()
        cands.append(cv2.resize(r, (tw, th), interpolation=cv2.INTER_AREA))
    # B) hoja de papel detectada en la foto, en las 4 orientaciones
    q = _quad_papel(img)
    if q is not None:
        dst = np.float32([[0, 0], [tw, 0], [tw, th], [0, th]])
        for k in range(4):
            M = cv2.getPerspectiveTransform(np.roll(q, k, axis=0), dst)
            cands.append(cv2.warpPerspective(img, M, (tw, th), flags=cv2.INTER_AREA, borderValue=(255, 255, 255)))
    refs = [_mapa(_normalizar(t[2]), 128) for t in tpls]
    refs = [(r - r.mean()) / (r.std() + 1e-6) for r in refs]
    punt = []
    for ci, c in enumerate(cands):
        m = _mapa(_normalizar(cv2.cvtColor(c, cv2.COLOR_BGR2GRAY)), 128)
        m = (m - m.mean()) / (m.std() + 1e-6)
        for pi, r in enumerate(refs):
            punt.append((float((m * r).mean()), ci, pi))
    punt.sort(reverse=True)
    mejor = None
    for sc_, ci, pi in punt[:4]:
        w = _ecc(cands[ci], tpls[pi][2], 0.25, 150)
        w = _ecc(w, tpls[pi][2], 0.5, 120)
        _, cob = _tinta_nueva(w, tpls[pi][2])
        if mejor is None or cob > mejor[1]:
            mejor = (pi, cob, w)
    if not mejor or mejor[1] < 0.45:
        return None
    return mejor


def _tinta_nueva(warped, tpl_gray):
    g = _normalizar(cv2.cvtColor(warped, cv2.COLOR_BGR2GRAY))
    ink = (g < 185).astype(np.uint8)
    tink = (tpl_gray < 200).astype(np.uint8)
    esperado = cv2.dilate(tink, np.ones((9, 9), np.uint8))
    extra = ink & (1 - esperado)
    extra = cv2.morphologyEx(extra, cv2.MORPH_OPEN, np.ones((2, 2), np.uint8))
    cobertura = float((tink & cv2.dilate(ink, np.ones((7, 7), np.uint8))).sum()) / max(1, int(tink.sum()))
    precision = 1.0 - float(extra.sum()) / max(1, int(ink.sum()))      # una imagen cualquiera (ruido, otra hoja) no cuadra con el formato
    if float(ink.mean()) > 0.3:                                        # demasiada tinta: no es una hoja escrita
        return extra, 0.0
    return extra, cobertura * max(0.0, precision)


def _score(extra, c, m=5):
    x, y, w, h = c
    return int(extra[y + m:y + h - m, x + m:x + w - m].sum())


def _decidir(scores, nombres):
    """-> (valor, dudoso). valor '' si no hay marca."""
    orden = sorted(range(len(scores)), key=lambda i: -scores[i])
    b = scores[orden[0]]
    if b < UMBRAL:
        return "", False
    s = scores[orden[1]]
    dudoso = s >= max(UMBRAL, 0.5 * b) or b < UMBRAL * 1.6
    return nombres[orden[0]], dudoso


def _limpia(img):
    """Quita sombras/fondo gris de la foto conservando el color de la tinta."""
    return cv2.merge([_normalizar(c) for c in cv2.split(img)])


def _png(img, calidad=None):
    ok, buf = cv2.imencode(".png", img)
    return base64.b64encode(buf.tobytes()).decode()


def _jpg(img, ancho=900):
    h, w = img.shape[:2]
    sc = ancho / float(w)
    ok, buf = cv2.imencode(".jpg", cv2.resize(img, None, fx=sc, fy=sc, interpolation=cv2.INTER_AREA), [cv2.IMWRITE_JPEG_QUALITY, 70])
    return base64.b64encode(buf.tobytes()).decode()


def leer(archivos):
    """archivos: [(nombre, bytes)]. Devuelve el resultado de la lectura (marcas, dudas, recortes y vistas previas)."""
    geo = geometria()
    _, tpls = _plantillas_sift()
    avisos, hojas = [], {}
    for nombre, datos in archivos:
        try:
            imgs = decodificar(nombre, datos)
        except Exception as e:
            avisos.append("No se pudo abrir «%s» (%s)." % (nombre, e))
            continue
        if not imgs:
            avisos.append("No se pudo abrir «%s»." % nombre)
            continue
        for k, im in enumerate(imgs):
            etiqueta = nombre if len(imgs) == 1 else "%s (página %d)" % (nombre, k + 1)
            r = alinear(im)
            if not r:
                avisos.append("«%s»: no se reconoció como una hoja del formato de observación. Toma la foto de frente, con la hoja completa y buena luz." % etiqueta)
                continue
            pi, inl, warped = r
            extra, cob = _tinta_nueva(warped, tpls[pi][2])
            inl = cob
            if cob < 0.6:
                avisos.append("«%s»: la imagen quedó poco alineada con el formato (%d%%); revisa las marcas con cuidado." % (etiqueta, int(cob * 100)))
            if pi not in hojas or inl > hojas[pi]["inl"]:
                hojas[pi] = {"inl": inl, "warped": warped, "extra": extra, "cob": cob, "nombre": etiqueta}
    res = {"generalidades": [""] * 7, "dims": [[""] * n for n in N_ITEMS], "dudas": [], "avisos": avisos,
           "crops": {"gen": [""] * 7, "obs": ""}, "previews": [], "hojas": sorted(h + 1 for h in hojas), "marcas": 0}
    if not hojas:
        return res
    over = {pi: h["warped"].copy() for pi, h in hojas.items()}
    for h_ in hojas.values():
        h_["limpia"] = _limpia(h_["warped"])

    def rect(pi, c, color):
        x, y, w, h = c
        cv2.rectangle(over[pi], (x, y), (x + w, y + h), color, 3)
    VERDE, NARANJA = (60, 170, 60), (0, 140, 255)
    # generalidades (hoja 1)
    if 0 in hojas:
        ex = hojas[0]["extra"]
        for i, fila in enumerate(geo["gen"]):
            val, dud = _decidir([_score(ex, c) for c in fila[:4]], GEN_COLS)
            res["generalidades"][i] = val
            if val:
                res["marcas"] += 1
                rect(0, fila[GEN_COLS.index(val)], NARANJA if dud else VERDE)
                if dud:
                    res["dudas"].append("g:%d" % i)
            x, y, w, h = fila[4]
            if _score(ex, fila[4], 3) >= 30:
                res["crops"]["gen"][i] = _png(hojas[0]["limpia"][y + 2:y + h - 2, x + 2:x + w - 2])
    else:
        avisos.append("No se recibió la hoja 1 (generalidades y dimensión 1): se llenará solo lo que venga en la otra hoja.")
    # dimensiones
    for k in range(4):
        for j, it in enumerate(geo["dims"][k]):
            pi = it["p"]
            if pi not in hojas:
                continue
            val, dud = _decidir([_score(hojas[pi]["extra"], c) for c in it["cells"]], DIM_COLS)
            res["dims"][k][j] = val
            if val:
                res["marcas"] += 1
                rect(pi, it["cells"][DIM_COLS.index(val)], NARANJA if dud else VERDE)
                if dud:
                    res["dudas"].append("d:%d:%d" % (k, j))
    if 1 not in hojas:
        avisos.append("No se recibió la hoja 2 (dimensiones 2 a 4 y observaciones): esos enunciados quedaron sin leer.")
    # observaciones escritas a mano (hoja 2)
    if 1 in hojas and geo["obs_y"]:
        y0, y1 = int((geo["obs_y"] + 1) * S), int(745 * S)
        x0, x1 = int(34 * S), int(578 * S)
        reg = hojas[1]["extra"][y0:y1, x0:x1]
        if int(reg.sum()) >= 200:
            res["crops"]["obs"] = _png(hojas[1]["limpia"][y0:y1, x0:x1])
    for pi in sorted(over):
        res["previews"].append({"hoja": pi + 1, "img": _jpg(over[pi])})
    return res


# ------------------------------------------------------------------ PDF oficial lleno
def _x(page, c, color=(0.05, 0.1, 0.55)):
    x, y, w, h = [v / S for v in c]
    cx, cy, r = x + w / 2, y + h / 2, min(w, h) * 0.28
    page.draw_line((cx - r, cy - r), (cx + r, cy + r), color=color, width=1.5)
    page.draw_line((cx - r, cy + r), (cx + r, cy - r), color=color, width=1.5)


def _texto_celda(page, c, txt, size=6.3):
    """Escribe texto dentro de una casilla: varias líneas si cabe, o una línea reducida/abreviada."""
    x, y, w, h = [v / S for v in c]
    azul = (0.05, 0.1, 0.55)
    anch = w - 4
    if h >= 20:
        if page.insert_textbox(fitz.Rect(x + 2, y + 1, x + w - 2, y + h - 1), txt, fontsize=size, fontname="helv", color=azul) >= 0:
            return
    sz = size
    while sz > 4.6 and fitz.get_text_length(txt, fontname="helv", fontsize=sz) > anch:
        sz -= 0.3
    while len(txt) > 3 and fitz.get_text_length(txt, fontname="helv", fontsize=sz) > anch:
        txt = txt[:-2].rstrip() + "…"
    page.insert_text((x + 2, y + h / 2 + sz * 0.33), txt, fontsize=sz, fontname="helv", color=azul)


def sellar_pdf(res, cfg, salida, conteo):
    """Llena una copia del PDF oficial (hojas 1 y 2) con las marcas, el encabezado y las observaciones."""
    geo = geometria()
    doc = fitz.open(PLANTILLA)
    doc.select([0, 1])
    pg = [doc[0], doc[1]]
    azul = (0.05, 0.1, 0.55)
    # encabezado (hoja 1)
    words = pg[0].get_text("words")

    def w_(t, n=0):
        m = [w for w in words if w[4] == t]
        return m[n] if len(m) > n else None
    datos = [("CCT:", cfg.get("cct", ""), 0), ("Nivel:", res.get("nivel", ""), 0), ("Docente:", res.get("docente", ""), 0),
             ("TURNO:", res.get("turno", ""), 0), ("Modalidad:", res.get("modalidad", ""), 0), ("grupo:", res.get("grado", ""), 0)]
    for etq, txt, _ in datos:
        w = w_(etq)
        if w and txt:
            pg[0].insert_text((w[2] + 4, w[3] - 2.5), str(txt), fontsize=8.5, fontname="helv", color=azul)
    # generalidades
    for i, fila in enumerate(geo["gen"]):
        val, obs = (res.get("generalidades") or [["", ""]] * 7)[i]
        if val in GEN_COLS:
            _x(pg[0], fila[GEN_COLS.index(val)])
        crop = (res.get("crops") or {}).get("gen", [""] * 7)[i] if res.get("crops") else ""
        x, y, w, h = [v / S for v in fila[4]]
        if obs:
            _texto_celda(pg[0], fila[4], obs)
        elif crop:
            pg[0].insert_image(fitz.Rect(x + 1, y + 1, x + w - 1, y + h - 1), stream=base64.b64decode(crop), keep_proportion=True)
    # dimensiones
    for k in range(4):
        marks = res["dims"][k]
        for j, it in enumerate(geo["dims"][k]):
            if marks[j] in DIM_COLS:
                _x(pg[it["p"]], it["cells"][DIM_COLS.index(marks[j])])
        s = geo["sub"][k]
        cont = conteo[k]
        if s and cont["marcados"]:
            n, p = cont["n"], cont["pct"]
            _texto_celda(pg[s["p"]], s["sub"], "RA %d  EP %d  L %d  D %d  NO %d" % (n["RA"], n["EP"], n["L"], n["D"], n["NO"]), 7.0)
            if s["pct"]:
                _texto_celda(pg[s["p"]], s["pct"], "RA %d%%  EP %d%%  L %d%%  D %d%%  NO %d%%" % (p["RA"], p["EP"], p["L"], p["D"], p["NO"]), 6.0)
    # observaciones
    texto = (res.get("observaciones") or "").strip()
    rayas = geo["rayas"]
    if texto and rayas:
        lineas = []
        for parte in texto.split("\n"):
            lineas += textwrap.wrap(parte, 120) or [""]
        for ln, y in zip(lineas, rayas):
            pg[1].insert_text((38, y - 2), ln, fontsize=8, fontname="helv", color=azul)
        if len(lineas) > len(rayas):
            pg[1].insert_text((38, rayas[-1] + 11), "(continúa en el Word…)", fontsize=7, fontname="helv", color=azul)
    elif (res.get("crops") or {}).get("obs") and geo["obs_y"]:
        pg[1].insert_image(fitz.Rect(34, geo["obs_y"] + 1, 578, 745), stream=base64.b64decode(res["crops"]["obs"]), keep_proportion=True)
    os.makedirs(os.path.dirname(salida), exist_ok=True)
    doc.save(salida, deflate=True)
    doc.close()
    return salida
