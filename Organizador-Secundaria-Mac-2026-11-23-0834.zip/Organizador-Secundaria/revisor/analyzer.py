# -*- coding: utf-8 -*-
"""Extracción de texto, reglas de verificación y llamada a la IA."""
import os, re, json, shutil, subprocess, tempfile, time, unicodedata, urllib.request, urllib.error
from rubrics import *

EXTRA_PATHS = ["/opt/homebrew/bin", "/usr/local/bin", "/usr/bin"]
if os.name != "nt":
    for _p in EXTRA_PATHS:
        if _p not in os.environ.get("PATH", ""):
            os.environ["PATH"] = os.environ.get("PATH", "") + ":" + _p

CONFIG_DIR = os.path.expanduser("~/.revisor-planeaciones")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")
DEFAULTS = {
    "root": "",
    "escuela": "",
    "escuela_regex": "",
    "cct": "",
    "ciclo": "2026-2027",
    "zona": "",
    "model": "claude-sonnet-5-5",
    "api_key": "",
    "proveedor": "anthropic",          # "anthropic" o "deepseek"
    "deepseek_key": "",
    "model_deepseek": "deepseek-flash",
}


def clave_activa(cfg):
    return cfg.get("deepseek_key", "") if cfg.get("proveedor") == "deepseek" else cfg.get("api_key", "")


def hay_ia(cfg):
    return bool(clave_activa(cfg))


def _datos_escuela_entorno():
    """Cuando el Revisor se abre desde «Organizador Secundaria» recibe los datos de LA ESCUELA de esa instalación
    (REVISOR_ESCUELA / _CCT / _CICLO / _ZONA): mandan sobre lo guardado, para que nunca salgan los datos de otra escuela."""
    esc = (os.environ.get("REVISOR_ESCUELA") or "").strip()
    if not esc:
        return {}
    palabras = [re.escape(w) for w in re.findall(r"\w+", unicodedata.normalize("NFD", esc).encode("ascii", "ignore").decode()) if len(w) > 2 and w.lower() not in ("esc", "sec", "gral", "fed", "secundaria")]
    d = {"escuela": esc, "escuela_regex": r"\s+".join(palabras) if palabras else re.escape(esc.lower())}
    for k, v in (("cct", "REVISOR_CCT"), ("ciclo", "REVISOR_CICLO"), ("zona", "REVISOR_ZONA")):
        if (os.environ.get(v) or "").strip():
            d[k] = os.environ[v].strip()
    return d


def load_config():
    cfg = dict(DEFAULTS)
    en_organizador = bool((os.environ.get("REVISOR_ESCUELA") or "").strip())
    if en_organizador:   # otra escuela: no arrancar con los datos de la escuela del autor
        cfg.update({"escuela": "", "escuela_regex": "", "cct": "", "zona": "", "root": os.path.expanduser("~/Documents")})
    try:
        with open(CONFIG_FILE, encoding="utf-8") as f:
            cfg.update(json.load(f))
    except Exception:
        pass
    cfg.update(_datos_escuela_entorno())
    if not cfg.get("api_key") and os.environ.get("ANTHROPIC_API_KEY"):
        cfg["api_key"] = os.environ["ANTHROPIC_API_KEY"]
    return cfg


def save_config(upd):
    cfg = load_config()
    for k in DEFAULTS:
        if k in upd and (k not in ("api_key", "deepseek_key") or upd[k] != ""):
            cfg[k] = upd[k]
    if upd.get("clear_api_key"):
        cfg["api_key"] = ""
    if upd.get("clear_deepseek_key"):
        cfg["deepseek_key"] = ""
    os.makedirs(CONFIG_DIR, exist_ok=True)
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    os.chmod(CONFIG_FILE, 0o600)
    return cfg


def public_config(cfg):
    c = dict(cfg)
    k = c.pop("api_key", ""); dk = c.pop("deepseek_key", "")
    c["claves"] = {"anthropic": {"set": bool(k), "hint": ("…" + k[-4:]) if k else ""},
                   "deepseek": {"set": bool(dk), "hint": ("…" + dk[-4:]) if dk else ""}}
    act = dk if c.get("proveedor") == "deepseek" else k
    c["api_key_set"] = bool(act)          # ¿hay clave para el proveedor elegido?
    c["api_key_hint"] = ("…" + act[-4:]) if act else ""
    return c


def norm(s):
    s = unicodedata.normalize("NFD", s or "")
    return "".join(ch for ch in s if unicodedata.category(ch) != "Mn").lower()


# ------------------------------------------------------------------ extracción
def _dump_docx(path):
    import docx
    from docx.table import Table
    from docx.text.paragraph import Paragraph
    from docx.oxml.ns import qn
    d = docx.Document(path)

    def tbl(t):
        out = []
        for r in t.rows:
            seen, cells = set(), []
            for c in r.cells:
                if id(c._tc) in seen:
                    continue
                seen.add(id(c._tc))
                txt = " / ".join(p.text.strip() for p in c.paragraphs if p.text.strip())
                for nt in c.tables:
                    txt += " [" + " || ".join(" | ".join(x.text.strip().replace("\n", " ") for x in rr.cells) for rr in nt.rows) + "]"
                cells.append(txt)
            out.append("| " + " | ".join(cells) + " |")
        return "\n".join(out)

    lines = []
    hdr = " ; ".join(p.text.strip() for s in d.sections for p in s.header.paragraphs if p.text.strip())
    if hdr:
        lines.append("ENCABEZADO: " + hdr)
    for s in d.sections:
        for t in s.header.tables:
            lines.append("ENCABEZADO-TABLA: " + tbl(t))
    for ch in d.element.body.iterchildren():
        if ch.tag == qn("w:p"):
            t = Paragraph(ch, d).text
            if t.strip():
                lines.append(t)
        elif ch.tag == qn("w:tbl"):
            lines.append(tbl(Table(ch, d)))
    ft = " ; ".join(p.text.strip() for s in d.sections for p in s.footer.paragraphs if p.text.strip())
    if ft:
        lines.append("PIE: " + ft)
    return "\n".join(lines)


def _soffice():
    """LibreOffice (para convertir a PDF y leer .doc viejos). Se busca en el PATH y en los lugares habituales de Mac y Windows."""
    w = shutil.which("soffice")
    if w:
        return w
    for c in ("/Applications/LibreOffice.app/Contents/MacOS/soffice",
              r"C:\Program Files\LibreOffice\program\soffice.exe", r"C:\Program Files (x86)\LibreOffice\program\soffice.exe"):
        if os.path.exists(c):
            return c
    return "soffice"


def _convert(path, fmt):
    out = tempfile.mkdtemp(prefix="revisor_")
    try:
        subprocess.run([_soffice(), "--headless", "--convert-to", fmt, "--outdir", out, path],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=120)
    except FileNotFoundError:
        return None
    res = [os.path.join(out, f) for f in os.listdir(out)]
    return res[0] if res else None


def _pdf_info_fitz(path):
    import fitz
    doc = fitz.open(path)
    txt, recorte = [], False
    for i, pg in enumerate(doc):
        txt.append(pg.get_text("text"))
        if i < 2:
            w = pg.rect.width
            words = pg.get_text("words")
            if sum(1 for x in words if x[0] < 1.5 or x[2] > w - 1.5) >= 3:
                recorte = True
    return "\n\f".join(txt), recorte


def pdf_info(path):
    """Texto del PDF y bandera de posible recorte de márgenes."""
    if not shutil.which("pdftotext"):   # sin poppler (Windows o Mac sin brew): se lee con PyMuPDF, que ya viene instalado
        return _pdf_info_fitz(path)
    txt = subprocess.run(["pdftotext", "-layout", path, "-"], capture_output=True, timeout=120).stdout.decode("utf-8", "ignore")
    recorte = False
    try:
        bb = subprocess.run(["pdftotext", "-bbox", path, "-"], capture_output=True, timeout=120).stdout.decode("utf-8", "ignore")
        for page in re.split(r"<page ", bb)[1:3]:
            w = float(re.search(r'width="([\d.]+)"', page).group(1))
            words = re.findall(r'xMin="([\d.]+)" yMin="[\d.]+" xMax="([\d.]+)"', page)
            if words:
                cut = sum(1 for a, b in words if float(a) < 1.5 or float(b) > w - 1.5)
                if cut >= 3:
                    recorte = True
    except Exception:
        pass
    return txt, recorte


def extract(path):
    """Devuelve (texto, info) donde info = {recorte: bool, error: str|None}."""
    ext = os.path.splitext(path)[1].lower()
    info = {"recorte": False, "error": None}
    try:
        if ext == ".docx":
            return _dump_docx(path), info
        if ext in (".doc", ".odt", ".rtf"):
            c = _convert(path, "docx")
            if c:
                return _dump_docx(c), info
            info["error"] = "No se pudo convertir (¿LibreOffice instalado?)"
            return "", info
        if ext == ".pdf":
            t, rec = pdf_info(path)
            info["recorte"] = rec
            if len(t.strip()) < 50:
                info["error"] = "PDF sin texto (posible escaneo/imagen)"
            return t, info
        if ext in (".txt", ".md"):
            return open(path, encoding="utf-8", errors="ignore").read(), info
        info["error"] = "Formato no soportado: " + ext
    except Exception as e:
        info["error"] = "Error al leer: %s" % e
    return "", info


# ------------------------------------------------------------------ clasificación
OTROS = re.compile(r"examen|diagn[oó]stic|reporte|informe|resultado|cuadernillo|test|prueba|gr[aá]fica|normconv|formato de sesiones|cte|nota de|extra[nñ]amiento|lista|horario|calificaci", re.I)
PROGRAMA = re.compile(r"programa\s*anal|plan\s*anal|programa\s*s\b|analitico|anal[ií]tico", re.I)
PLANO = re.compile(r"plan|planeaci|plano|proyecto|secuencia|trimestre", re.I)


def classify(name, text=""):
    """plano | programa | otro. Por nombre; lo que no se reconoce como «otro» se asume plano (editable en la interfaz)."""
    n = norm(name)
    if os.path.splitext(n)[1] not in (".docx", ".doc", ".pdf", ".txt", ".odt", ".rtf"):
        return "otro"
    if PROGRAMA.search(n):
        return "programa"
    if OTROS.search(n) and not re.search(r"plan(eaci|o)", n):
        return "otro"
    if re.search(r"PLANO UNO|PLANO 1:|ANÁLISIS DEL CONTEXTO SOCIOEDUCATIVO", text or "", re.I):
        return "programa"
    return "plano"


def trimestre_en_nombre(name):
    n = norm(name)
    m = re.search(r"(primer|segundo|tercer)\s+trim", n)
    if m:
        return {"primer": 1, "segundo": 2, "tercer": 3}[m.group(1)]
    m = re.search(r"trim\w*\s*(?:#|no\.?)?\s*([123])\b", n) or re.search(r"\b([123])\s*[°º]?\s*(?:er|o)?\s*trim", n)
    return int(m.group(1)) if m else None


# ------------------------------------------------------------------ reglas
def reglas_identificacion(texto, cfg, docente, trimestre, campo_hint=""):
    """Verificación determinista de datos de identificación. Devuelve (lista, otras)."""
    t = norm(texto)
    head = t[:3500]
    ident, otras = [], []

    # escuela
    if cfg.get("escuela_regex") and re.search(cfg["escuela_regex"], t):
        ident.append(["Nombre de la escuela", "ok", "Aparece «%s»." % cfg["escuela"]])
    elif "carrillo puerto" in (cfg.get("escuela") or "").lower() and re.search(r"carillo\s+puerto", t):
        ident.append(["Nombre de la escuela", "no", "Está mal escrito («CARILLO»); debe ser «Carrillo»."])
    else:
        ident.append(["Nombre de la escuela", "no", "No se encuentra el nombre de la escuela en el documento."])
    # CCT
    cct = (cfg.get("cct") or "").lower()
    found = set(re.findall(r"\b\d{2}\s?d[a-z]{2}\s?\d{4}\s?[a-z]\b", t))
    if not cct:
        pass   # la escuela no tiene CCT capturado: no se verifica
    elif cct in re.sub(r"\s", "", t):
        ident.append(["C.C.T.", "ok", cfg["cct"] + "."])
    elif found:
        ident.append(["C.C.T.", "no", "Aparece un CCT distinto: " + ", ".join(x.upper() for x in found)])
    else:
        ident.append(["C.C.T.", "no", "No se anota el CCT (%s)." % cfg["cct"]])
    # ciclo
    if not re.match(r"^\d{4}-\d{4}$", cfg.get("ciclo") or ""):
        cfg = dict(cfg, ciclo="2026-2027")   # ciclo mal capturado: se usa el vigente
    a, b = cfg["ciclo"].split("-")
    c1, c2 = cfg["ciclo"][2:4], cfg["ciclo"][7:9]
    ok_pat = re.compile(r"%s\s*[-–/]\s*(?:%s|%s)\b" % (a, b, b[-2:]))
    bad = re.findall(r"\b(20(?:2[0-5]))\s*[-–/]\s*(20\d\d|\d\d)\b", t)
    if ok_pat.search(t):
        extra = ""
        if bad:
            extra = " Pero también aparece un ciclo distinto: " + ", ".join("%s-%s" % x for x in bad[:3]) + "."
            ident.append(["Ciclo escolar", "warn", "Aparece %s.%s" % (cfg["ciclo"], extra)])
        else:
            ident.append(["Ciclo escolar", "ok", cfg["ciclo"] + "."])
    elif re.search(r"ciclo\s*escolar\s*:?\s*\|?\s*(%s\s*/\s*%s|%s-%s)" % (c1, c2, c1, c2), t) or re.search(r"\b%s\s*/\s*%s\b" % (c1, c2), t):
        ident.append(["Ciclo escolar", "warn", "Dice «%s/%s»; debe decir %s." % (c1, c2, cfg["ciclo"])])
    elif bad:
        ident.append(["Ciclo escolar", "no", "Aparece el ciclo " + ", ".join("%s-%s" % x for x in bad[:3]) + "; debe ser %s." % cfg["ciclo"]])
    else:
        ident.append(["Ciclo escolar", "no", "No se anota el ciclo escolar %s." % cfg["ciclo"]])
    # fechas de otro año
    ant = re.findall(r"(?:ene|feb|mar|abr|may|jun|jul|ago|sep|oct|nov|dic)[a-z]*\.?[\s\-de]*(?:2023|2024|2025)\b", t)
    if ant:
        otras.append("Se encontraron fechas de años anteriores (%s): posible texto copiado de otro ciclo." % ", ".join(sorted(set(ant))[:3]))
    corto = re.findall(r"(?<![\d/.])(2[0-5])\s*[-/]\s*(2[1-6])(?![\d/])", t)
    corto = [c for c in corto if int(c[1]) - int(c[0]) == 1 and "%s%s" % c != cfg["ciclo"][2:4] + cfg["ciclo"][7:9]]
    if corto:
        otras.append("Aparece un ciclo abreviado distinto (%s): posible texto copiado de otro ciclo." % ", ".join("%s-%s" % c for c in sorted(set(corto))[:3]))
    # trimestre
    n = int(trimestre) if str(trimestre).isdigit() else 0
    nombres = {1: "primer", 2: "segundo", 3: "tercer"}
    if n:
        pat = r"%s\s*trimestre|trimestre\s*[:#]?\s*\|?\s*%d\b|%d\s*[°º.]?\s*(?:o\s*)?trimestre|periodo\s*[:|]*\s*%s\s*trimestre" % (nombres[n], n, n, nombres[n])
        if re.search(pat, t):
            ident.append(["Trimestre / periodo", "ok", "Se indica el %s trimestre." % nombres[n]])
        else:
            ident.append(["Trimestre / periodo", "warn", "No se indica claramente el %s trimestre (revisar encabezado/periodo)." % nombres[n]])
        for m, nm in nombres.items():
            if m != n and re.search(r"%s\s*trimestre" % nm, t):
                if m < n:
                    otras.append("Menciona el «%s trimestre» dentro de la planeación del %s: verificar que no sea texto copiado." % (nm, nombres[n]))
                else:
                    otras.append("Menciona el «%s trimestre» en la planeación del %s: verificar." % (nm, nombres[n]))
    # campo formativo
    if re.search(r"campo\s*formativo\s*:?\s*\|?\s*lenguaje\b(?!s)", t):
        ident.append(["Campo formativo", "no", "Dice «LENGUAJE»; debe decir «LENGUAJES»."])
    elif re.search(r"lenguajes|saberes y pensamiento|etica, naturaleza|de lo humano", t):
        ident.append(["Campo formativo", "ok", "Se indica el campo formativo."])
    else:
        ident.append(["Campo formativo", "warn", "No se identifica claramente el campo formativo."])
    # docente
    toks = [x for x in norm(docente).split() if len(x) > 2]
    hit = [x for x in toks if x in t]
    if toks and len(hit) >= min(2, len(toks)):
        ident.append(["Docente", "ok", "Aparece el nombre del docente."])
    elif hit:
        ident.append(["Docente", "warn", "Solo se encuentra parte del nombre (%s)." % ", ".join(hit)])
    else:
        ident.append(["Docente", "no", "No aparece el nombre del docente en el documento."])
    # grado y grupo
    if re.search(r"\b[123]\s*[°º\.o]?\s*[\"“«']?\s*[a-f]\b|grado\s*y\s*grupo|grupo\s*:", t):
        ident.append(["Grado y grupo", "ok", "Se indica grado/grupo (confirmar contra el horario)."])
    else:
        ident.append(["Grado y grupo", "no", "No se indica grado y grupo."])
    # plantilla sin llenar
    if len(re.findall(r"_{5,}", texto)) >= 4:
        otras.append("El documento conserva varias líneas en blanco de la plantilla («______»).")
    return ident, otras


# ------------------------------------------------------------------ IA
def _post(cfg, body, tries=3):
    if cfg.get("proveedor") == "deepseek":
        url, headers = "https://api.deepseek.com/chat/completions", {"Authorization": "Bearer " + cfg["deepseek_key"], "content-type": "application/json"}
    else:
        url, headers = "https://api.anthropic.com/v1/messages", {"x-api-key": cfg["api_key"], "anthropic-version": "2023-06-01", "content-type": "application/json"}
    req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"), headers=headers)
    last = None
    for i in range(tries):
        try:
            with urllib.request.urlopen(req, timeout=300) as r:
                return json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            msg = e.read().decode("utf-8", "ignore")
            last = "HTTP %s: %s" % (e.code, msg[:300])
            if e.code in (429, 500, 502, 503, 529):
                time.sleep(4 * (i + 1)); continue
            raise RuntimeError(last)
        except Exception as e:
            last = str(e); time.sleep(3)
    raise RuntimeError("No se pudo contactar a la IA: " + str(last))


def _json_from(text):
    text = text.strip()
    text = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M).strip()
    i, j = text.find("{"), text.rfind("}")
    return json.loads(text[i:j + 1])


def build_prompt(tipo, docente, trimestre, disciplina, grado, bloques, cfg, reglas_txt):
    if tipo == "plano":
        schema = ('{"datos":{"disciplina":"","campo":"","grado_grupo":""},'
                  '"niveles":[{"n":1,"nivel":1,"obs":""}, ... exactamente 20 elementos, n=1..20 en el orden de los reactivos],'
                  '"otras":["observaciones generales: fortalezas y problemas de congruencia, copias, errores"],'
                  '"tareas":["correcciones concretas que debe hacer el docente"],'
                  '"resumen":"2-3 oraciones para el director antes de observar la clase"}')
        lista = "\n".join("%d. %s" % (i + 1, r) for i, r in enumerate([x for _, items in FACTORES for x in items]))
        inst = "Aplica el INSTRUMENTO PARA LA REVISIÓN DEL PLANO DIDÁCTICO.\nREACTIVOS (n=1..20):\n%s\n\nCRITERIOS:\n%s" % (lista, CRITERIOS_PLANO)
    else:
        schema = ('{"datos":{"disciplina":"","campo":"","grado_grupo":""},'
                  '"guia":[{"n":1,"marca":"SI|NO|NA","obs":""}, ... exactamente 28 elementos],'
                  '"otras":[""],"tareas":[""],"resumen":""}')
        lista = "\n".join("%d. %s" % (i + 1, r) for i, r in enumerate([x for _, items in GUIA_PA for x in items]))
        inst = ("Aplica la GUÍA PARA EL ANÁLISIS DE PROGRAMA ANALÍTICO. Marca SI solo si el componente se aprecia con claridad; "
                "si está incompleto, incorrecto o ajeno al campo, marca NO y explica qué falta. Indicadores (n=1..28):\n" + lista)
    partes = []
    for b in bloques:
        partes.append("=== ARCHIVO: %s %s===\n%s" % (b["name"], "(PDF con posible recorte de márgenes) " if b.get("recorte") else "", b["text"]))
    return ("%s\n\nDATOS DEL CASO\nDocente: %s\nTrimestre a revisar: %s\nDisciplina (según carpeta/usuario): %s\nGrado/grupo (según usuario): %s\n"
            "Escuela esperada: %s, CCT %s, ciclo %s.\n\nVERIFICACIONES AUTOMÁTICAS PREVIAS (ya hechas por el sistema; no las repitas):\n%s\n\n"
            "FORMATO DE RESPUESTA (solo JSON):\n%s\n\nDOCUMENTOS DEL DOCENTE:\n%s"
            % (inst, docente, trimestre, disciplina or "-", grado or "-", cfg["escuela"], cfg["cct"], cfg["ciclo"], reglas_txt or "(ninguna)", schema, "\n\n".join(partes)))


def llamar_ia(cfg, prompt):
    if os.environ.get("REVISOR_MOCK"):
        return {"__mock__": True}
    if cfg.get("proveedor") == "deepseek":
        modelo = cfg.get("model_deepseek") or "deepseek-flash"
        body = {"model": modelo, "max_tokens": 8000, "temperature": 0.2,
                "messages": [{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": prompt}]}
        if "reasoner" not in modelo:
            body["response_format"] = {"type": "json_object"}
        txt = ""
        for intento in range(3):   # DeepSeek a veces devuelve el contenido vacío en modo JSON: se reintenta (el último intento sin modo JSON)
            if intento == 2:
                body.pop("response_format", None)
            r = _post(cfg, body)
            txt = (((r.get("choices") or [{}])[0].get("message") or {}).get("content") or "").strip()
            if "{" in txt:
                break
            time.sleep(2)
        if "{" not in txt:
            raise RuntimeError("La IA (DeepSeek) devolvió una respuesta vacía 3 veces seguidas. Vuelve a intentarlo en unos minutos.")
        return _json_from(txt)
    body = {"model": cfg["model"], "max_tokens": 8000, "system": SYSTEM_PROMPT,
            "messages": [{"role": "user", "content": prompt}]}
    r = _post(cfg, body)
    txt = "".join(b.get("text", "") for b in r.get("content", []) if b.get("type") == "text")
    return _json_from(txt)


def _fit(texts, limit_each=45000, limit_total=150000):
    out, total = [], 0
    for b in texts:
        t = re.sub(r"[ \t]+", " ", b["text"])
        t = re.sub(r"\n{3,}", "\n\n", t)
        if len(t) > limit_each:
            t = t[:limit_each] + "\n[... texto truncado por longitud ...]"
        if total + len(t) > limit_total:
            t = t[: max(0, limit_total - total)] + "\n[... truncado ...]"
        total += len(t)
        out.append(dict(b, text=t))
    return out


def analizar(cfg, docente, trimestre, tipo, archivos, disciplina="", grado="", progreso=None):
    """archivos: lista de rutas. Devuelve dict de resultado listo para editar y generar Word."""
    def prog(m):
        if progreso:
            progreso(m)
    prog("Leyendo archivos…")
    bloques, notas, nombres = [], [], []
    for p in archivos:
        txt, info = extract(p)
        nombres.append(os.path.basename(p))
        if info["error"]:
            notas.append("%s: %s" % (os.path.basename(p), info["error"]))
        if info["recorte"]:
            notas.append("%s: el PDF parece tener los márgenes recortados (puede faltar texto en los extremos); valoraciones provisionales." % os.path.basename(p))
        if txt.strip():
            bloques.append({"name": os.path.basename(p), "text": txt, "recorte": info["recorte"]})
    if not bloques:
        raise RuntimeError("No se pudo leer texto de ningún archivo. " + " ".join(notas))
    todo = "\n".join(b["text"] for b in bloques)
    prog("Verificando datos de identificación…")
    ident, otras_reglas = reglas_identificacion(todo, cfg, docente, trimestre)
    reglas_txt = "\n".join("- %s: %s (%s)" % (a, c, b) for a, b, c in ident) + "\n" + "\n".join("- " + o for o in otras_reglas)

    res = {
        "docente": docente.upper(), "trimestre": int(trimestre) if str(trimestre).isdigit() else trimestre,
        "instrumento": "plano" if tipo == "plano" else "guia_pa",
        "campo": "", "disciplina": disciplina or "", "grado": grado or "",
        "archivos": nombres, "identificacion": ident, "otras": list(otras_reglas) + [("Archivo: " + n) for n in notas],
        "tareas": [], "resumen": "", "estado": "", "ia": False,
        "niveles": [[0, ""] for _ in range(N_REACTIVOS)] if tipo == "plano" else None,
        "guia": [["", ""] for _ in range(N_GUIA)] if tipo != "plano" else None,
    }
    if hay_ia(cfg) or os.environ.get("REVISOR_MOCK"):
        prog("Analizando con IA (puede tardar 1-3 minutos)…")
        pr = build_prompt(tipo, docente, trimestre, disciplina, grado, _fit(bloques), cfg, reglas_txt)
        r = llamar_ia(cfg, pr)
        res["ia"] = True
        if r.get("__mock__"):
            if tipo == "plano":
                res["niveles"] = [[2, "(simulado) Observación de prueba."] for _ in range(N_REACTIVOS)]
            else:
                res["guia"] = [["SI" if i % 2 else "NO", "(simulado)"] for i in range(N_GUIA)]
            res["otras"].append("Modo simulado: no se llamó a la IA."); res["tareas"] = ["(simulado) Tarea de prueba."]
            res["resumen"] = "Resumen simulado."
        else:
            d = r.get("datos", {})
            res["campo"] = d.get("campo", "") or res["campo"]
            res["disciplina"] = res["disciplina"] or d.get("disciplina", "")
            res["grado"] = res["grado"] or d.get("grado_grupo", "")
            if tipo == "plano":
                for it in r.get("niveles", []):
                    k = int(it.get("n", 0)) - 1
                    if 0 <= k < N_REACTIVOS:
                        lv = it.get("nivel", 0)
                        res["niveles"][k] = [int(lv) if str(lv).isdigit() and 0 <= int(lv) <= 4 else 0, str(it.get("obs", ""))]
            else:
                for it in r.get("guia", []):
                    k = int(it.get("n", 0)) - 1
                    if 0 <= k < N_GUIA:
                        m = str(it.get("marca", "")).upper().replace("Í", "I")
                        res["guia"][k] = [m if m in ("SI", "NO", "NA") else "", str(it.get("obs", ""))]
            res["otras"] = [str(x) for x in r.get("otras", [])] + res["otras"]
            res["tareas"] = [str(x) for x in r.get("tareas", [])]
            res["resumen"] = str(r.get("resumen", ""))
    else:
        res["otras"].append("No hay clave de IA configurada: solo se hicieron las verificaciones automáticas. Marca los niveles manualmente.")
    # estado automático
    malos = sum(1 for _, t, _ in ident if t == "no")
    res["estado"] = "ENTREGADO — " + ("REQUIERE CORRECCIONES" if malos or res["tareas"] else "SIN OBSERVACIONES GRAVES")
    return res
