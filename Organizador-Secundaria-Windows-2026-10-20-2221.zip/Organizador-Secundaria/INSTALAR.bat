@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Organizador Secundaria - Instalar / Actualizar
REM INSTALAR / ACTUALIZAR (Windows). Doble clic. Copia el programa a un lugar fijo y crea los accesos directos en el Escritorio.
REM Tus datos (navegador) y tu licencia (carpeta de usuario) NO se tocan. Despues puedes borrar esta carpeta y el .zip.
echo === Organizador Secundaria - instalar / actualizar ===
where node >nul 2>nul
if errorlevel 1 (
  echo Falta instalar Node.js ^(programa gratuito de apoyo^). Abre el instalador node-...msi que te enviaron y vuelve a abrir INSTALAR.
  pause
  exit /b 1
)
set "BASE=%LOCALAPPDATA%\OrganizadorSecundaria"
set "DEST=%BASE%\Programa"
set "PUERTO=5544"
REM detener el programa si estaba abierto (actualizacion)
for /f "tokens=5" %%p in ('netstat -ano ^| findstr ":%PUERTO% " ^| findstr LISTENING') do taskkill /PID %%p /F >nul 2>nul
timeout /t 1 /nobreak >nul
rem Los horarios que subio la escuela (horarios\) NO se pierden al reinstalar: se apartan y se devuelven.
if exist "%BASE%\.horarios-apartados" rmdir /s /q "%BASE%\.horarios-apartados"
if exist "%DEST%\horarios" move "%DEST%\horarios" "%BASE%\.horarios-apartados" >nul
if exist "%DEST%" rmdir /s /q "%DEST%"
mkdir "%DEST%"
xcopy "%~dp0*" "%DEST%\" /E /I /Y /Q >nul
if exist "%BASE%\.horarios-apartados" (
  if not exist "%DEST%\horarios" mkdir "%DEST%\horarios"
  xcopy "%BASE%\.horarios-apartados\*" "%DEST%\horarios\" /E /I /Y /Q >nul
  rmdir /s /q "%BASE%\.horarios-apartados"
)
del "%DEST%\INSTALAR.command" >nul 2>nul
REM accesos directos en el Escritorio (sin ventana negra)
powershell -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell; $d=[Environment]::GetFolderPath('Desktop'); $s=$w.CreateShortcut($d+'\Organizador Secundaria.lnk'); $s.TargetPath='wscript.exe'; $s.Arguments='\"%DEST%\Abrir.vbs\"'; $s.WorkingDirectory='%DEST%'; $s.Description='Organizador Secundaria'; $s.Save(); $c=$w.CreateShortcut($d+'\Organizador Secundaria (celulares).lnk'); $c.TargetPath='wscript.exe'; $c.Arguments='\"%DEST%\Abrir-celulares.vbs\"'; $c.WorkingDirectory='%DEST%'; $c.Description='Organizador Secundaria - enlace para prefectas'; $c.Save()"
REM icono de los accesos = logo de la escuela (si ya lo subio) o el predeterminado
node "%DEST%\server.js" --actualizar-iconos >nul 2>nul
echo.
echo Listo. Se instalo el programa en: %DEST%
echo Se crearon en tu Escritorio: "Organizador Secundaria" y "Organizador Secundaria (celulares)".
echo Ya puedes borrar esta carpeta y el .zip.
start "" wscript.exe "%DEST%\Abrir.vbs"
pause
