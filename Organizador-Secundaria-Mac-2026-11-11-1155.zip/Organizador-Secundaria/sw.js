const CACHE = "escuela-fcp-v142";

const ARCHIVOS = [
  "/",
  "/index.html",
  "/src/app.js"
];

self.addEventListener("install", event => {
  self.skipWaiting();

  event.waitUntil(
    caches.open(CACHE).then(cache => {
      return cache.addAll(ARCHIVOS);
    })
  );
});

self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys().then(keys => {
      return Promise.all(
        keys
          .filter(key => key !== CACHE)
          .map(key => caches.delete(key))
      );
    }).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", event => {

  if(event.request.method !== "GET") return;

  // No cachear imagenes de horarios
  if(event.request.url.includes("/horarios/")) {
    event.respondWith(fetch(event.request));
    return;
  }

  event.respondWith(

    fetch(event.request)
      .then(response => {

        if(
          event.request.url.startsWith("http")
        ){
          const clone = response.clone();

          caches.open(CACHE).then(cache => {
            cache.put(event.request, clone);
          });
        }

        return response;

      })
      .catch(() => {
        return caches.match(event.request);
      })

  );

});
