' Abre Organizador Secundaria en modo "con celulares" y copia al portapapeles el enlace para las prefectas.
Option Explicit
Dim sh, fso, carpeta, puerto, i, ip, enlace, ex
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
carpeta = fso.GetParentFolderName(WScript.ScriptFullName)
puerto = "5544"
Function Corre()
  Corre = (sh.Run("cmd /c curl -s -m 1 -o nul http://127.0.0.1:" & puerto & "/api/licencia/estado", 0, True) = 0)
End Function
' reiniciar el servidor en modo red
sh.Run "cmd /c for /f ""tokens=5"" %p in ('netstat -ano ^| findstr "":" & puerto & " "" ^| findstr LISTENING') do taskkill /PID %p /F", 0, True
WScript.Sleep 1000
sh.CurrentDirectory = carpeta
sh.Environment("Process")("FCP_RED") = "1"
sh.Run "cmd /c node server.js", 0, False
For i = 1 To 60
  WScript.Sleep 250
  If Corre() Then Exit For
Next
Set ex = sh.Exec("powershell -NoProfile -Command ""(Get-NetIPConfiguration | Where-Object {$_.IPv4DefaultGateway -ne $null} | Select-Object -First 1).IPv4Address.IPAddress""")
ip = Trim(ex.StdOut.ReadAll())
enlace = "http://" & ip & ":" & puerto & "/prefectos/index.html"
sh.Run "cmd /c echo " & enlace & "| clip", 0, True
MsgBox "Enlace para las prefectas (ya copiado, solo pegalo en WhatsApp):" & vbCrLf & vbCrLf & enlace & vbCrLf & vbCrLf & "Deben estar en el MISMO wifi y esta computadora encendida. Si Windows pregunta por el Firewall, elige Permitir.", 64, "Reportes de prefectas"
sh.Run "http://localhost:" & puerto
