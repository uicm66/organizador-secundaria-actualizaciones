' Abre Organizador Secundaria sin ventana negra: arranca el servidor en segundo plano (si no esta corriendo) y abre el navegador.
Option Explicit
Dim sh, fso, carpeta, puerto, i
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
carpeta = fso.GetParentFolderName(WScript.ScriptFullName)
puerto = "5544"
Function Corre()
  Corre = (sh.Run("cmd /c curl -s -m 1 -o nul http://127.0.0.1:" & puerto & "/api/licencia/estado", 0, True) = 0)
End Function
If Not Corre() Then
  sh.CurrentDirectory = carpeta
  sh.Run "cmd /c node server.js", 0, False
  For i = 1 To 60
    WScript.Sleep 250
    If Corre() Then Exit For
  Next
End If
sh.Run "http://localhost:" & puerto
